<?php include('header.php');
$left=13;
?>
<script src="js/ajax.js" type="text/javascript"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
<!-- main menu-->
<?php include('leftpanel.php'); ?>
<!-- / main menu-->

<div class="app-content content container-fluid">
<div class="content-wrapper" style="min-height:590px;">

<div class="content-body">
<div class="row">
<div class="col-xs-12">
<div class="card">
<div class="card-header">
<h4 class="card-title">View Recharge</h4>
<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
<div class="heading-elements">
<ul class="list-inline mb-0">
<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
<li><a data-action="reload"><i class="icon-reload"></i></a></li>
<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
</ul>
</div>
</div>

<div class="card-body collapse in">

<div align="right" style="padding:5px;"><form name="frm1" method="post" action="view-recharge.php?act=search"><input type="text" name="search" id="search" class="form-control input-line input-medium" value="<?=$_REQUEST['search']?>" required placeholder="User ID, Order ID, Phone Number" style="width:250px;" />
</form></div>

<div class="card-body" style="overflow:auto;background:#FFFFFF;">
 <table id="example1" class="table table-bordered table-striped">
<thead>
<tr>
<th style="text-align:center;" width="10%">Sl_No.</th>
<th style="text-align:center;" width="15%">User_ID</th>
<th style="text-align:center;" width="15%">Name</th>
<th style="text-align:center;" width="15%">Order_ID</th>
<th style="text-align:center;" width="15%">Operator</th>
<th style="text-align:center;" width="15%">Phone</th>
<th style="text-align:center;" width="15%">Recharge_Amount</th>
<th style="text-align:center;" width="15%">Charge</th>
<th style="text-align:center;" width="15%">Total</th>
<th style="text-align:center;" width="10%">Status</th>
<th style="text-align:center;" width="10%">TxnID</th>
<th style="text-align:center;" width="10%">Jolo_Order_ID</th>
<th style="text-align:center;" width="10%">Service_Type</th>
<th style="text-align:center;" width="10%">Error</th>
<th style="text-align:center;" width="10%">Date</th>
</tr>
</thead>
<tbody>

<?php
$tname='or_member_recharge';
$lim=100;
$tpage='view-recharge.php';
if($_REQUEST['act']=='search')
{
$where="WHERE `userid` LIKE '".trim(mysqli_real_escape_string($conn,$_POST['search']))."' OR `orderid` LIKE '".trim(mysqli_real_escape_string($conn,$_POST['search']))."' OR `phone` LIKE '".trim(mysqli_real_escape_string($conn,$_POST['search']))."' ORDER BY `id` DESC";
}else{
$where="ORDER BY `id` DESC";
}
include('pagination.php');
$num=numrows($result);
$i=1;
if($num>0)
{
while($fetch=fetcharray($result))
{
?>
<tr>
<td align="center" style="padding:5px;"><?=$i?></td>
<td align="center" style="padding:5px;"><?=$fetch['userid']?></td>
<td align="center" style="padding:5px;"><?=getMemberUserID($conn,$fetch['userid'],'name')?></td>
<td align="center" style="padding:5px;"><?=$fetch['orderid']?></td>
<td align="center" style="padding:5px;"><?=getOperatorByCode($conn,$fetch['operator'])?></td>
<td align="center" style="padding:5px;"><?=$fetch['phone']?></td>
<td align="center" style="padding:5px;"><?=$fetch['amount']?></td>
<td align="center" style="padding:5px;"><?=$fetch['charge']?></td>
<td align="center" style="padding:5px;"><?=$fetch['total']?></td>
<td align="center" style="padding:5px;">
<?php if($fetch['status']=='SUCCESS'){?><span style="color:#009900;">SUCCESS</span><?php }?>
<?php if($fetch['status']=='PENDING'){?><span style="color:#FF9900;">PENDING</span><?php }?>
<?php if($fetch['status']=='FAILURE'){?><span style="color:#FF0000;">FAILURE</span><?php }?>
</td>
<td align="center" style="padding:5px;"><?=$fetch['txnid']?></td>
<td align="center" style="padding:5px;"><?=$fetch['joloorderid']?></td>
<td align="center" style="padding:5px;"><?=$fetch['servicetype']?></td>
<td align="center" style="padding:5px;"><?=$fetch['error']?></td>
<td align="center" style="padding:5px;"><?=$fetch['date']?></td>
</tr>
<?php $i++;}}else{?>
<tr><td colspan="15" align="center" style="color:#FF0000;">No Record Found!</td></tr>
<?php }?>

</tbody>
</table>
</div>
<div align="center"><?=$pagination?></div>

</div>
</div>
</div>
</div>


</div>
</div>
</div>

<!-- BEGIN VENDOR JS-->
<script src="app-assets/js/core/libraries/jquery.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/tether.min.js" type="text/javascript"></script>
<script src="app-assets/js/core/libraries/bootstrap.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/unison.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/blockUI.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/jquery.matchHeight-min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/screenfull.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/extensions/pace.min.js" type="text/javascript"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<!-- END PAGE VENDOR JS-->
<!-- BEGIN ROBUST JS-->
<script src="app-assets/js/core/app-menu.js" type="text/javascript"></script>
<script src="app-assets/js/core/app.js" type="text/javascript"></script>
<!-- END ROBUST JS-->
<!-- BEGIN PAGE LEVEL JS-->
<!-- END PAGE LEVEL JS-->
</body>
</html>
