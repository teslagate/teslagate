<?php
session_start();
include('includes/function.php');

if($_REQUEST['case']=='add')
{
$sql="SELECT * FROM `or_recharge_operator` WHERE `code`='".mysqli_real_escape_string($conn,$_POST['code'])."'";
$res=query($conn,$sql);
$num=numrows($res);
if($num>0)
{
redirect('operator.php?case=add&m=1');
}else{

$sql="INSERT INTO `or_recharge_operator` (`operator`,`code`) VALUES ('".mysqli_real_escape_string($conn,$_POST['operator'])."','".mysqli_real_escape_string($conn,$_POST['code'])."')";
$res=query($conn,$sql);
redirect('operator.php?case=add&m=2');
}
}

if($_REQUEST['case']=='edit') 
{
$sql1="UPDATE `or_recharge_operator` SET `operator`='".trim(mysqli_real_escape_string($conn,$_POST['operator']))."',`code`='".trim(mysqli_real_escape_string($conn,$_POST['code']))."' WHERE `id`='".mysqli_real_escape_string($conn,$_REQUEST['id'])."'";
$res1=query($conn,$sql1);

redirect('operator.php?m=1');
}

if($_REQUEST['case']=='delete')
{
$sql="DELETE FROM `or_recharge_operator`  WHERE `id`='".mysqli_real_escape_string($conn,$_REQUEST['id'])."'";
$res=query($conn,$sql); 


redirect('operator.php?page='.$_REQUEST['page']);
}

?>