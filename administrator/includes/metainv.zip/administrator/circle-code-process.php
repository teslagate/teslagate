<?php
session_start();
include('includes/function.php');

if($_REQUEST['case']=='add')
{

$sql="SELECT * FROM `or_recharge_circle_code` WHERE `state`='".mysqli_real_escape_string($conn,$_POST['state'])."'  ";
$res=query($conn,$sql);
$num=numrows($res);
if($num>0)
{
redirect('circle-code.php?case=add&m=1');
}else{
$sql="INSERT INTO `or_recharge_circle_code` (`state`,`code`) VALUES ('".mysqli_real_escape_string($conn,$_POST['state'])."','".mysqli_real_escape_string($conn,$_POST['code'])."')";
$res=query($conn,$sql);
redirect('circle-code.php?case=add&m=2');
}
}
 
if($_REQUEST['case']=='edit')
{
$sql="SELECT * FROM `or_recharge_circle_code` WHERE `state`='".mysqli_real_escape_string($conn,$_POST['state'])."'  ";
$res=query($conn,$sql);
$num=numrows($res);
if($num>0)
{
redirect('circle-code.php?case=edit&e=1');
}else{

$sql1="UPDATE `or_recharge_circle_code` SET `state`='".trim(mysqli_real_escape_string($conn,$_POST['state']))."',`code`='".trim(mysqli_real_escape_string($conn,$_POST['code']))."' WHERE `id`='".mysqli_real_escape_string($conn,$_REQUEST['id'])."'";
$res1=query($conn,$sql1);

redirect('circle-code.php?m=1');
}
}



if($_REQUEST['case']=='delete')
{
$sql="DELETE FROM `or_recharge_circle_code`  WHERE `id`='".mysqli_real_escape_string($conn,$_REQUEST['id'])."'";
$res=query($conn,$sql); 


redirect('circle-code.php?page='.$_REQUEST['page']);
}

?>