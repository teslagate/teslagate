<?php
include('header.php');
$left=1;
include('calculate-recharge-release.php');
?>
<!-- main menu-->
<?php include('leftpanel.php') ?>
<!-- / main menu-->

<div class="app-content content container-fluid">
	<div class="content-wrapper" style="background:#FFFFFF;"> 
		<div class="content-header row">
		</div>

		<div class="content-body" style="min-height:518px;">

			<div align="center">&nbsp;</div>  
			<div class="row">
				<div class="col-xl-3 col-lg-6 col-xs-12">
					<div class="card" style="border-radius:10px;">
						<a href="member.php" style="color:#373a3c;">
							<div class="card-body" style="background:#0b1313; min-height:105px;border-radius:10px;">
								<div class="card-block">
									<div class="media">
										<div class="media-body text-xs-left">
											<h3 class="white"><?=getTotalMember($conn)?></h3>
											<span class="white">Total Member</span>
										</div>
										<div class="media-right media-middle">
											<i class="icon-user white font-large-2 float-xs-right"></i>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
				</div>

				<div class="col-xl-3 col-lg-6 col-xs-12">
					<div class="card" style="border-radius:10px;">
						<a href="member.php" style="color:#fff;">
							<div class="card-body" style="background:#129033; min-height:105px;border-radius:10px;">
								<div class="card-block">
									<div class="media">
										<div class="media-body text-xs-left">
											<h3 style="color:#FFFFFF;"><?=getActiveMember($conn)?></h3>
											<span>Active Member</span>
										</div>
										<div class="media-right media-middle" >
											<i class="icon-user white font-large-2 float-xs-right" ></i>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
				</div>

				<div class="col-xl-3 col-lg-6 col-xs-12">
					<div class="card" style="border-radius:10px;">
						<a href="member.php" style="color:#373a3c;">
							<div class="card-body" style="background:#b72a0c; min-height:105px;border-radius:10px;">
								<div class="card-block">
									<div class="media">
										<div class="media-body text-xs-left">
											<h3 class="white"><?=getInactiveMember($conn)?></h3>
											<span class="white">Inctive Member</span>
										</div>
										<div class="media-right media-middle">
											<i class="icon-user white font-large-2 float-xs-right"></i>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
				</div>


				<div class="col-xl-3 col-lg-6 col-xs-12">
					<div class="card" style="border-radius:10px;">
						<a href="commission-binary.php" style="color:#fff;">
							<div class="card-body" style="background-color:slateblue; min-height:105px;border-radius:10px;">
								<div class="card-block">
									<div class="media">
										<div class="media-body text-xs-left">
											<h3 class="violet" style="color:#FFFFFF;"><?=getTotalBinaryBonus($conn)?></h3>
											<span>Binary Bonus</span>
										</div>
										<div class="media-right media-middle">
											<i class="icon-dollar violet font-large-2 float-xs-right"></i>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
				</div>

				<div class="col-xl-3 col-lg-6 col-xs-12">
					<div class="card" style="border-radius:10px;"><a href="commission-direct.php" style="color:#fff;"><div class="card-body" style="background-color:slateblue; min-height:105px;border-radius:10px;">

						<div class="card-block">
							<div class="media"><div class="media-body text-xs-left"><h3 class="violet" style="color:#FFFFFF;"><?=getTotalDirectBonus($conn)?></h3><span>Direct Bonus</span></div><div class="media-right media-middle"><i class="icon-dollar violet font-large-2 float-xs-right"></i></div></div></div></div></a></div>
						</div>








						<div class="col-xl-3 col-lg-6 col-xs-12">
							<div class="card" style="border-radius:10px;">
								<a href="pending-withdrawal.php" style="color:#fff;">
									<div class="card-body" style="background:orange; min-height:105px;border-radius:10px;">
										<div class="card-block">
											<div class="media">
												<div class="media-body text-xs-left">
													<h3 class="violet" style="color:#FFFFFF;"><?=getPendingWithdrawalAdmin($conn)?></h3>
													<span>Pending Withdrawal</span>
												</div>
												<div class="media-right media-middle">
													<i class="icon-money violet font-large-2 float-xs-right"></i>
												</div>
											</div>
										</div>
									</div>
								</a>
							</div>
						</div>

						<div class="col-xl-3 col-lg-6 col-xs-12">
							<div class="card" style="border-radius:10px;">
								<a href="approved-withdrawal.php" style="color:#333333;">
									<div class="card-body" style="background:#129033; min-height:105px;border-radius:10px;">
										<div class="card-block">
											<div class="media">
												<div class="media-body text-xs-left">
													<h3 style="color:#FFFFFF;"><?=getApprovedWithdrawalAdmin($conn)?></h3>
													<span style="color:#FFFFFF;">Approved Withdrawal</span>
												</div>
												<div class="media-right media-middle">
													<i class="icon-money white font-large-2 float-xs-right"></i>
												</div>
											</div>
										</div>
									</div>
								</a>
							</div>
						</div>

						<div class="col-xl-3 col-lg-6 col-xs-12">
							<div class="card" style="border-radius:10px;">
								<a href="epin.php" style="color:#fff;">
									<div class="card-body" style="background:#38503e; min-height:105px;border-radius:10px;">
										<div class="card-block">
											<div class="media">
												<div class="media-body text-xs-left">
													<h3  style="color:#fff;"><?=getEpinAdmin($conn)?></h3>
													<span style="color:#fff;">Total Available Epin</span>
												</div>
												<div class="media-right media-middle">
													<i class="icon-pin white font-large-2 float-xs-right"></i>
												</div>
											</div>
										</div>
									</div>
								</a>
							</div>
						</div>

						<div class="col-xl-3 col-lg-6 col-xs-12">
							<div class="card" style="border-radius:10px;">
								<a href="epin.php" style="color:#fff;">
									<div class="card-body" style="background:#b72a0c; min-height:105px;border-radius:10px;">
										<div class="card-block">
											<div class="media">
												<div class="media-body text-xs-left">
													<h3  style="color:#FFFF00;"><?=getUsedEpinAdmin($conn)?></h3>
													<span style="color:#FFFF00;">Total Used Epin</span>
												</div>
												<div class="media-right media-middle">
													<i class="icon-pin yellow font-large-2 float-xs-right"></i>
												</div>
											</div>
										</div>
									</div>
								</a>
							</div>
						</div>

						<div class="col-xl-3 col-lg-6 col-xs-12">
							<div class="card" style="border-radius:10px;">
								<a href="support.php" style="color:#fff;">
									<div class="card-body" style="background:#3F51B5; min-height:105px;border-radius:10px;">
										<div class="card-block">
											<div class="media">
												<div class="media-body text-xs-left">
													<h3 style="color:#FFFFFF;"><?=getTotalSupport($conn)?></h3>
													<span>Total Support</span>
												</div>
												<div class="media-right media-middle">
													<i class="icon-help white font-large-2 float-xs-right"></i>
												</div>
											</div>
										</div>
									</div>
								</a>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>

<div class="hk-footer-wrap container">
    <footer class="footer">
        <div class="row">
            <div class="col-md-8">
                <p>All rights reserved and <a href="<?=$weblink ?>" class="text-dark" rel="noopener noreferrer" target="_blank"><?= $copyright ?></a> © 2021</p>
            </div>
            
        </div>
    </footer>
</div>

<!-- BEGIN VENDOR JS-->
<script src="app-assets/js/core/libraries/jquery.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/tether.min.js" type="text/javascript"></script>
<script src="app-assets/js/core/libraries/bootstrap.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/unison.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/blockUI.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/jquery.matchHeight-min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/screenfull.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/extensions/pace.min.js" type="text/javascript"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<script src="app-assets/vendors/js/charts/chart.min.js" type="text/javascript"></script>
<!-- END PAGE VENDOR JS-->
<!-- BEGIN ROBUST JS-->
<script src="app-assets/js/core/app-menu.js" type="text/javascript"></script>
<script src="app-assets/js/core/app.js" type="text/javascript"></script>
<!-- END ROBUST JS-->
<!-- BEGIN PAGE LEVEL JS-->
<script src="app-assets/js/scripts/pages/dashboard-lite.js" type="text/javascript"></script>
<!-- END PAGE LEVEL JS-->
</body>
</html>
