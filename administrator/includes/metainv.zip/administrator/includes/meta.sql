-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2022 at 05:58 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `meta`
--

-- --------------------------------------------------------

--
-- Table structure for table `direct_income`
--

CREATE TABLE `direct_income` (
  `id` int(11) NOT NULL,
  `userid` varchar(255) NOT NULL,
  `dowlineid` varchar(255) NOT NULL,
  `amount` varchar(200) NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `direct_income`
--

INSERT INTO `direct_income` (`id`, `userid`, `dowlineid`, `amount`, `date`) VALUES
(3, 'MRMS7737111', 'MFEST8364144', '100', '2021-10-21'),
(4, 'MFEST8364144', 'MFEST9845482', '100', '2021-10-22'),
(5, 'MFEST8364144', 'MFEST9721932', '100', '2021-10-22'),
(6, 'MFEST8364144', 'MFEST7028066', '100', '2021-10-24'),
(7, 'MFEST8364144', 'MFEST6513325', '100', '2021-10-24'),
(8, 'MFEST8364144', 'MFEST3003604', '100', '2021-10-24'),
(9, 'MFEST8364144', 'MFEST4171836', '100', '2021-10-24'),
(10, 'MFEST4171836', 'MFEST8570054', '100', '2021-10-24'),
(11, 'MFEST8570054', 'MFEST8019211', '100', '2021-10-24'),
(12, 'MFEST8364144', 'MFEST6302611', '100', '2021-10-24'),
(13, 'MFEST9721932', 'MFEST6477979', '100', '2021-10-25'),
(14, 'MFEST9721932', 'MFEST6805897', '100', '2021-10-25'),
(15, 'MFEST9721932', 'MFEST6299914', '100', '2021-10-25'),
(16, 'MFEST9845482', 'MFEST7024248', '100', '2021-10-29'),
(17, 'MFEST9845482', 'MFEST1785700', '100', '2021-11-03'),
(18, 'MFEST7024248', 'MFEST7513921', '100', '2021-11-03'),
(19, 'MFEST7024248', 'MFEST2290083', '100', '2021-11-03'),
(20, 'MFEST6513325', 'MFEST2435084', '100', '2021-11-03'),
(21, 'MFEST3003604', 'MFEST7351181', '100', '2021-11-03'),
(22, 'MFEST7513921', 'MFEST1367439', '100', '2021-11-03'),
(23, 'MFEST7028066', 'MFEST5676467', '100', '2021-11-20'),
(24, 'MFEST8364144', 'MFEST8423036', '200', '2021-11-20'),
(25, 'MFEST8423036', 'MFEST7364342', '240', '2021-11-20'),
(26, 'MFEST8364144', 'MFEST7708616', '100', '2021-11-22'),
(27, 'MFEST8364144', 'MFEST5219779', '50', '2021-11-25');

-- --------------------------------------------------------

--
-- Table structure for table `gm_settings_level`
--

CREATE TABLE `gm_settings_level` (
  `id` int(11) NOT NULL,
  `level` varchar(20) NOT NULL,
  `income` double(15,2) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gm_settings_level`
--

INSERT INTO `gm_settings_level` (`id`, `level`, `income`, `datetime`) VALUES
(20, 'Level 6', 19.00, '2021-10-18 13:12:40'),
(19, 'Level 5', 20.00, '2021-10-18 13:12:40'),
(18, 'Level 4', 22.00, '2021-10-18 13:12:40'),
(17, 'Level 3', 25.00, '2021-10-18 13:12:40'),
(16, 'Level 2', 28.00, '2021-10-18 13:12:40'),
(15, 'Level 1', 30.00, '2021-10-18 13:12:40'),
(21, 'Level 7', 18.00, '2021-10-18 13:12:40'),
(22, 'Level 8', 15.00, '2021-10-18 13:12:40'),
(23, 'Level 9', 10.00, '2021-10-18 13:12:40'),
(24, 'Level 10', 5.00, '2021-10-18 13:12:40');

-- --------------------------------------------------------

--
-- Table structure for table `metamask`
--

CREATE TABLE `metamask` (
  `ID` int(11) NOT NULL,
  `address` varchar(42) NOT NULL,
  `publicName` tinytext DEFAULT NULL,
  `nonce` tinytext DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `or_admin`
--

CREATE TABLE `or_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `role` enum('S','A') NOT NULL,
  `status` enum('A','I') NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_admin`
--

INSERT INTO `or_admin` (`id`, `username`, `password`, `name`, `email`, `phone`, `role`, `status`, `datetime`) VALUES
(1, 'YWRtaW4=', 'MTIzNDU2', '', '', '', '', 'A', '2022-05-15 16:23:52');

-- --------------------------------------------------------

--
-- Table structure for table `or_carrer_plan`
--

CREATE TABLE `or_carrer_plan` (
  `id` int(11) NOT NULL,
  `pack_name` varchar(255) NOT NULL,
  `joining` double(15,2) NOT NULL,
  `bv` varchar(255) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `or_commission_binary`
--

CREATE TABLE `or_commission_binary` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `leftmem` int(11) NOT NULL,
  `rightmem` int(11) NOT NULL,
  `minimum` int(11) NOT NULL,
  `binary` double(15,2) NOT NULL,
  `bonus` double(15,2) NOT NULL,
  `date` varchar(10) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_commission_binary`
--

INSERT INTO `or_commission_binary` (`id`, `userid`, `leftmem`, `rightmem`, `minimum`, `binary`, `bonus`, `date`, `datetime`) VALUES
(2, 'MFEST8364144', 1000, 1000, 1000, 10.00, 100.00, '2021-10-22', '2021-10-22 14:51:59'),
(3, 'MFEST8364144', 1000, 1000, 1000, 10.00, 100.00, '2021-10-24', '2021-10-24 17:35:48'),
(4, 'MFEST4171836', 2000, 1000, 1000, 10.00, 100.00, '2021-10-24', '2021-10-24 18:14:00'),
(5, 'MFEST9721932', 1000, 6000, 1000, 10.00, 100.00, '2021-10-25', '2021-10-24 18:41:52'),
(6, 'MFEST9721932', 1000, 5000, 1000, 10.00, 100.00, '2021-10-25', '2021-10-25 15:43:21'),
(7, 'MFEST9721932', 1000, 4000, 1000, 10.00, 100.00, '2021-10-25', '2021-10-25 15:46:07'),
(8, 'MFEST8364144', 1000, 8000, 1000, 10.00, 100.00, '2021-10-29', '2021-10-29 09:50:13'),
(9, 'MFEST9845482', 1000, 1000, 1000, 10.00, 100.00, '2021-10-29', '2021-10-29 09:50:13'),
(10, 'MFEST8364144', 1000, 7000, 1000, 10.00, 100.00, '2021-11-03', '2021-11-03 10:39:31'),
(11, 'MFEST8364144', 1000, 6000, 1000, 10.00, 100.00, '2021-11-03', '2021-11-03 10:43:02'),
(12, 'MFEST7024248', 1000, 1000, 1000, 10.00, 100.00, '2021-11-03', '2021-11-03 10:43:02'),
(13, 'MFEST8364144', 1000, 5000, 1000, 10.00, 100.00, '2021-11-03', '2021-11-03 10:46:59'),
(14, 'MFEST6513325', 1000, 5000, 1000, 10.00, 100.00, '2021-11-03', '2021-11-03 10:50:48'),
(15, 'MFEST3003604', 1000, 4000, 1000, 10.00, 100.00, '2021-11-03', '2021-11-03 10:54:03'),
(16, 'MFEST8364144', 1000, 6000, 1000, 10.00, 100.00, '2021-11-03', '2021-11-03 10:56:51'),
(17, 'MFEST7513921', 1000, 1000, 1000, 10.00, 100.00, '2021-11-03', '2021-11-03 10:56:51'),
(18, 'MFEST8364144', 1000, 5000, 1000, 10.00, 100.00, '2021-11-20', '2021-11-20 12:27:50'),
(19, 'MFEST9845482', 1000, 4000, 1000, 10.00, 100.00, '2021-11-20', '2021-11-20 12:27:50'),
(20, 'MFEST8364144', 2000, 4000, 2000, 10.00, 200.00, '2021-11-20', '2021-11-20 12:41:51'),
(21, 'MFEST9845482', 2000, 3000, 2000, 10.00, 200.00, '2021-11-20', '2021-11-20 12:41:51'),
(22, 'MFEST7028066', 2000, 1000, 1000, 10.00, 100.00, '2021-11-20', '2021-11-20 12:41:51'),
(23, 'MFEST8364144', 2000, 2000, 2000, 10.00, 200.00, '2021-11-20', '2021-11-20 12:47:47'),
(24, 'MFEST9845482', 2000, 1000, 1000, 10.00, 100.00, '2021-11-20', '2021-11-20 12:47:47');

-- --------------------------------------------------------

--
-- Table structure for table `or_commission_binary_matching`
--

CREATE TABLE `or_commission_binary_matching` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `leftmem` int(11) NOT NULL,
  `rightmem` int(11) NOT NULL,
  `minimum` int(11) NOT NULL,
  `binary` double(15,2) NOT NULL,
  `bonus` double(15,2) NOT NULL,
  `date` varchar(10) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_commission_binary_matching`
--

INSERT INTO `or_commission_binary_matching` (`id`, `userid`, `leftmem`, `rightmem`, `minimum`, `binary`, `bonus`, `date`, `datetime`) VALUES
(1, 'MRMS7737111', 25, 200, 25, 0.50, 0.12, '2021-10-18', '2021-10-18 15:01:19'),
(2, 'MFEST8364144', 100, 100, 100, 100.00, 100.00, '2021-10-22', '2021-10-22 14:51:59'),
(3, 'MFEST8364144', 100, 100, 100, 100.00, 100.00, '2021-10-24', '2021-10-24 17:35:48'),
(4, 'MFEST4171836', 200, 100, 100, 100.00, 100.00, '2021-10-24', '2021-10-24 18:14:00'),
(5, 'MFEST9721932', 100, 600, 100, 100.00, 100.00, '2021-10-25', '2021-10-24 18:41:52'),
(6, 'MFEST9721932', 100, 500, 100, 100.00, 100.00, '2021-10-25', '2021-10-25 15:43:21'),
(7, 'MFEST9721932', 100, 400, 100, 100.00, 100.00, '2021-10-25', '2021-10-25 15:46:07'),
(8, 'MFEST8364144', 100, 800, 100, 100.00, 100.00, '2021-10-29', '2021-10-29 09:50:13'),
(9, 'MFEST9845482', 100, 100, 100, 100.00, 100.00, '2021-10-29', '2021-10-29 09:50:13'),
(10, 'MFEST8364144', 100, 700, 100, 100.00, 100.00, '2021-11-03', '2021-11-03 10:39:31'),
(11, 'MFEST8364144', 100, 600, 100, 100.00, 100.00, '2021-11-03', '2021-11-03 10:43:02'),
(12, 'MFEST7024248', 100, 100, 100, 100.00, 100.00, '2021-11-03', '2021-11-03 10:43:02'),
(13, 'MFEST8364144', 100, 500, 100, 100.00, 100.00, '2021-11-03', '2021-11-03 10:46:59'),
(14, 'MFEST6513325', 100, 500, 100, 100.00, 100.00, '2021-11-03', '2021-11-03 10:50:48'),
(15, 'MFEST3003604', 100, 400, 100, 100.00, 100.00, '2021-11-03', '2021-11-03 10:54:03'),
(16, 'MFEST8364144', 100, 600, 100, 100.00, 100.00, '2021-11-03', '2021-11-03 10:56:51'),
(17, 'MFEST7513921', 100, 100, 100, 100.00, 100.00, '2021-11-03', '2021-11-03 10:56:51'),
(18, 'MFEST8364144', 100, 500, 100, 100.00, 100.00, '2021-11-20', '2021-11-20 12:27:50'),
(19, 'MFEST9845482', 100, 400, 100, 100.00, 100.00, '2021-11-20', '2021-11-20 12:27:50'),
(20, 'MFEST8364144', 200, 400, 200, 100.00, 200.00, '2021-11-20', '2021-11-20 12:41:51'),
(21, 'MFEST9845482', 200, 300, 200, 100.00, 200.00, '2021-11-20', '2021-11-20 12:41:51'),
(22, 'MFEST7028066', 200, 100, 100, 100.00, 100.00, '2021-11-20', '2021-11-20 12:41:51'),
(23, 'MFEST8364144', 200, 200, 200, 100.00, 200.00, '2021-11-20', '2021-11-20 12:47:47'),
(24, 'MFEST9845482', 200, 100, 100, 100.00, 100.00, '2021-11-20', '2021-11-20 12:47:47');

-- --------------------------------------------------------

--
-- Table structure for table `or_company`
--

CREATE TABLE `or_company` (
  `id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `f_year` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `firm_value` int(11) NOT NULL,
  `binary1` varchar(100) NOT NULL,
  `direct` varchar(255) NOT NULL,
  `capping` double(15,2) NOT NULL,
  `recharge` double(15,2) NOT NULL,
  `nomonth` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_company`
--

INSERT INTO `or_company` (`id`, `company_name`, `f_year`, `description`, `firm_value`, `binary1`, `direct`, `capping`, `recharge`, `nomonth`, `datetime`) VALUES
(2, 'TeslaGateway', 2022, 'We\'ve always known that managing IT for government, enterprise, enterprise, large and small businesses can be a real challenge. That\'s why we strive to provide the highest quality services. We offer DIGITAL ARCHIVE SOFTWARE for government agencies and municipalities, NETWORK MARKETING SOFTWARE for Marketing Companies, COURSES MANAGEMENT SYSTEM for Classrooms, Schools and Courses, Professional WEB DESIGN for Companies, SEO, SOCIAL MEDIA and CYBER SECURITY SOLUTIONS.\n', 1, '25', '6', 30000.00, 50.00, 3, '2022-05-14 18:59:35'),
(3, 'Google', 1888, '50', 8, '50', '8', 30000.00, 50.00, 3, '2022-05-14 20:47:48'),
(4, 'Facebook', 1950, '100', 10, '100', '10', 30000.00, 50.00, 3, '2022-05-14 20:47:50'),
(5, 'Twitter', 2000, '200', 10, '200', '12', 30000.00, 50.00, 3, '2022-05-14 20:46:41'),
(8, 'Netflix', 2010, '400', 10, '400', '15', 30000.00, 0.00, 3, '2022-05-14 20:47:57');

-- --------------------------------------------------------

--
-- Table structure for table `or_deposit`
--

CREATE TABLE `or_deposit` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `amount` double(15,2) NOT NULL,
  `remarks` varchar(150) NOT NULL,
  `date` varchar(10) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_deposit`
--

INSERT INTO `or_deposit` (`id`, `userid`, `amount`, `remarks`, `date`, `datetime`) VALUES
(13, 'MRMS5532564', 500.00, 'Binary', '2021-01-21', '2021-10-18 13:12:40'),
(14, 'MRMS5532564', 200.00, 'Piad', '2021-01-21', '2021-10-18 13:12:40'),
(15, 'MRMS5030038', 200.00, 'Binary ', '2021-01-22', '2021-10-18 13:12:40'),
(16, 'MRMS3498045', 200.00, 'Depos', '2021-10-01', '2021-10-18 13:12:40');

-- --------------------------------------------------------

--
-- Table structure for table `or_epin`
--

CREATE TABLE `or_epin` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `packid` varchar(200) NOT NULL,
  `toid` varchar(20) NOT NULL,
  `epin` varchar(30) NOT NULL,
  `status` enum('A','U') NOT NULL,
  `generate` varchar(20) NOT NULL,
  `usedby` varchar(20) NOT NULL,
  `usedon` varchar(10) NOT NULL,
  `date` varchar(10) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_epin`
--

INSERT INTO `or_epin` (`id`, `userid`, `packid`, `toid`, `epin`, `status`, `generate`, `usedby`, `usedon`, `date`, `datetime`) VALUES
(219, '', '4', '', 'DBD01E6B54472D6', 'U', 'Administrator', 'MRMS7737111', '2021-10-01', '2021-10-01', '2021-10-19 18:43:05'),
(269, 'MRMS7927832', '3', 'MRMS7927832', 'BB5B076E747E571', 'U', 'Administrator', 'MRMS7927832', '2021-10-12', '2021-10-12', '2021-10-18 13:12:40'),
(270, 'MRMS6521463', '4', 'MRMS6521463', '4F793ACCC8F3704', 'U', 'Administrator', 'MRMS6521463', '2021-10-12', '2021-10-12', '2021-10-18 13:12:40'),
(271, 'MFEST7367301', '2', 'MFEST7367301', '41ACE934EA32B30', 'U', 'Administrator', 'MFEST7367301', '2021-10-18', '2021-10-18', '2021-10-18 13:53:30'),
(272, 'MFEST3798738', '4', 'MFEST3798738', '4DFC3C50E386BDE', 'U', 'Administrator', 'MFEST3798738', '2021-10-18', '2021-10-18', '2021-10-18 15:01:19'),
(273, 'MFEST8364144', '4', 'MFEST8364144', '1C5CD07FAD9FB83', 'U', 'Administrator', 'MFEST8364144', '2021-10-21', '2021-10-20', '2021-10-20 18:30:51'),
(274, 'MFEST9845482', '4', 'MFEST9845482', '73915A288181C1C', 'U', 'Administrator', 'MFEST9845482', '2021-10-22', '2021-10-22', '2021-10-22 14:16:48'),
(275, 'MFEST9721932', '4', 'MFEST9721932', 'D4D86AC1BE68B8D', 'U', 'Administrator', 'MFEST9721932', '2021-10-22', '2021-10-22', '2021-10-22 14:51:59'),
(276, 'MFEST7028066', '4', 'MFEST7028066', '790F9758A4252E0', 'U', 'Administrator', 'MFEST7028066', '2021-10-24', '2021-10-24', '2021-10-24 17:28:46'),
(277, 'MFEST6513325', '4', 'MFEST6513325', '8CD4BC7E33BA4BC', 'U', 'Administrator', 'MFEST6513325', '2021-10-24', '2021-10-24', '2021-10-24 17:35:48'),
(278, 'MFEST3003604', '4', 'MFEST3003604', '85D71FD3D8A82B2', 'U', 'Administrator', 'MFEST3003604', '2021-10-24', '2021-10-24', '2021-10-24 17:38:53'),
(279, 'MFEST4171836', '4', 'MFEST4171836', '71921C469144454', 'U', 'Administrator', 'MFEST4171836', '2021-10-24', '2021-10-24', '2021-10-24 17:42:36'),
(280, 'MFEST8570054', '4', 'MFEST8570054', '12ABD5D8A901BD7', 'U', 'Administrator', 'MFEST8570054', '2021-10-24', '2021-10-24', '2021-10-24 18:04:40'),
(281, 'MFEST8019211', '4', 'MFEST8019211', 'D933266C43D41D0', 'U', 'Administrator', 'MFEST8019211', '2021-10-24', '2021-10-24', '2021-10-24 18:10:09'),
(282, 'MFEST6302611', '4', 'MFEST6302611', 'C52AA0A2A2E8F4F', 'U', 'Administrator', 'MFEST6302611', '2021-10-24', '2021-10-24', '2021-10-24 18:14:00'),
(283, 'MFEST6477979', '4', 'MFEST6477979', '8D53F1B5566BE1F', 'U', 'Administrator', 'MFEST6477979', '2021-10-25', '2021-10-25', '2021-10-24 18:41:52'),
(284, 'MFEST6805897', '4', 'MFEST6805897', '85589A8285BB58D', 'U', 'Administrator', 'MFEST6805897', '2021-10-25', '2021-10-25', '2021-10-25 15:43:21'),
(285, 'MFEST6299914', '4', 'MFEST6299914', '73D072E4270DD34', 'U', 'Administrator', 'MFEST6299914', '2021-10-25', '2021-10-25', '2021-10-25 15:46:07'),
(286, 'MFEST7024248', '4', 'MFEST7024248', 'B294BDEB434408B', 'U', 'Administrator', 'MFEST7024248', '2021-10-29', '2021-10-29', '2021-10-29 09:50:13'),
(287, 'MFEST1785700', '4', 'MFEST1785700', '96E453D07340532', 'U', 'Administrator', 'MFEST1785700', '2021-11-03', '2021-11-03', '2021-11-03 10:39:31'),
(288, 'MFEST7513921', '4', 'MFEST7513921', '82208499B146864', 'U', 'Administrator', 'MFEST7513921', '2021-11-03', '2021-11-03', '2021-11-03 10:43:02'),
(289, 'MFEST2290083', '4', 'MFEST2290083', '2959C952D9AB882', 'U', 'Administrator', 'MFEST2290083', '2021-11-03', '2021-11-03', '2021-11-03 10:46:59'),
(290, 'MFEST2435084', '4', 'MFEST2435084', '253A6AD5836D3C0', 'U', 'Administrator', 'MFEST2435084', '2021-11-03', '2021-11-03', '2021-11-03 10:50:48'),
(291, 'MFEST7351181', '4', 'MFEST7351181', '3F0B40D4BE8AB11', 'U', 'Administrator', 'MFEST7351181', '2021-11-03', '2021-11-03', '2021-11-03 10:54:03'),
(292, 'MFEST1367439', '4', 'MFEST1367439', 'B898FA3F7011E06', 'U', 'Administrator', 'MFEST1367439', '2021-11-03', '2021-11-03', '2021-11-03 10:56:51'),
(293, 'MFEST5676467', '4', 'MFEST5676467', 'F3308A57CF2A142', 'U', 'Administrator', 'MFEST5676467', '2021-11-20', '2021-11-20', '2021-11-20 12:27:50'),
(294, 'MFEST8423036', '5', 'MFEST8423036', '58BA328DF098C52', 'U', 'Administrator', 'MFEST8423036', '2021-11-20', '2021-11-20', '2021-11-20 12:41:51'),
(295, 'MFEST7364342', '5', 'MFEST7364342', '4BDE5E05386E8D0', 'U', 'Administrator', 'MFEST7364342', '2021-11-20', '2021-11-20', '2021-11-20 12:47:47'),
(296, 'MFEST7708616', '4', 'MFEST7708616', '78CBBD06D767E24', 'U', 'Administrator', 'MFEST7708616', '2021-11-22', '2021-11-22', '2021-11-22 15:07:51'),
(297, 'MFEST5219779', '3', 'MFEST5219779', '58A29257C27E7E5', 'U', 'Administrator', 'MFEST5219779', '2021-11-25', '2021-11-25', '2021-11-25 06:54:31');

-- --------------------------------------------------------

--
-- Table structure for table `or_genealogy`
--

CREATE TABLE `or_genealogy` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `placement` varchar(20) NOT NULL,
  `position` varchar(20) NOT NULL,
  `date` varchar(10) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_genealogy`
--

INSERT INTO `or_genealogy` (`id`, `userid`, `placement`, `position`, `date`, `datetime`) VALUES
(51, 'MRMS7737111', '', '', '2020-11-30', '2021-10-18 13:12:40'),
(113, 'MFEST8364144', 'MRMS7737111', 'Left', '2021-10-21', '2021-10-20 18:30:51'),
(114, 'MFEST9845482', 'MFEST8364144', 'Left', '2021-10-22', '2021-10-22 14:16:48'),
(115, 'MFEST9721932', 'MFEST8364144', 'Right', '2021-10-22', '2021-10-22 14:51:59'),
(116, 'MFEST7028066', 'MFEST9845482', 'Left', '2021-10-24', '2021-10-24 17:28:46'),
(117, 'MFEST6513325', 'MFEST9721932', 'Right', '2021-10-24', '2021-10-24 17:35:48'),
(118, 'MFEST3003604', 'MFEST6513325', 'Right', '2021-10-24', '2021-10-24 17:38:53'),
(119, 'MFEST4171836', 'MFEST3003604', 'Right', '2021-10-24', '2021-10-24 17:42:36'),
(120, 'MFEST8570054', 'MFEST4171836', 'Left', '2021-10-24', '2021-10-24 18:04:40'),
(121, 'MFEST8019211', 'MFEST8570054', 'Left', '2021-10-24', '2021-10-24 18:10:09'),
(122, 'MFEST6302611', 'MFEST4171836', 'Right', '2021-10-24', '2021-10-24 18:14:00'),
(123, 'MFEST6477979', 'MFEST9721932', 'Left', '2021-10-25', '2021-10-24 18:41:52'),
(124, 'MFEST6805897', 'MFEST6477979', 'Left', '2021-10-25', '2021-10-25 15:43:21'),
(125, 'MFEST6299914', 'MFEST6805897', 'Left', '2021-10-25', '2021-10-25 15:46:07'),
(126, 'MFEST7024248', 'MFEST9845482', 'Right', '2021-10-29', '2021-10-29 09:50:13'),
(127, 'MFEST1785700', 'MFEST7024248', 'Right', '2021-11-03', '2021-11-03 10:39:31'),
(128, 'MFEST7513921', 'MFEST7024248', 'Left', '2021-11-03', '2021-11-03 10:43:02'),
(129, 'MFEST2290083', 'MFEST7513921', 'Left', '2021-11-03', '2021-11-03 10:46:59'),
(130, 'MFEST2435084', 'MFEST6513325', 'Left', '2021-11-03', '2021-11-03 10:50:48'),
(131, 'MFEST7351181', 'MFEST3003604', 'Left', '2021-11-03', '2021-11-03 10:54:03'),
(132, 'MFEST1367439', 'MFEST7513921', 'Right', '2021-11-03', '2021-11-03 10:56:51'),
(133, 'MFEST5676467', 'MFEST7028066', 'Right', '2021-11-20', '2021-11-20 12:27:50'),
(134, 'MFEST8423036', 'MFEST7028066', 'Left', '2021-11-20', '2021-11-20 12:41:51'),
(135, 'MFEST7364342', 'MFEST8423036', 'Left', '2021-11-20', '2021-11-20 12:47:47'),
(136, 'MFEST7708616', 'MFEST7364342', 'Left', '2021-11-22', '2021-11-22 15:07:51'),
(137, 'MFEST5219779', 'MFEST7708616', 'Left', '2021-11-25', '2021-11-25 06:54:31');

-- --------------------------------------------------------

--
-- Table structure for table `or_member`
--

CREATE TABLE `or_member` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `sponsor` varchar(20) NOT NULL,
  `sponpos` varchar(30) NOT NULL,
  `placement` varchar(20) NOT NULL,
  `position` varchar(20) NOT NULL,
  `package` varchar(10) NOT NULL,
  `carrerplan` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `bname` varchar(100) NOT NULL,
  `branch` varchar(30) NOT NULL,
  `accname` varchar(30) NOT NULL,
  `accno` varchar(30) NOT NULL,
  `usdtwallet` varchar(40) NOT NULL,
  `minerincome` varchar(30) NOT NULL,
  `ifscode` varchar(20) NOT NULL,
  `aadhar` varchar(20) NOT NULL,
  `pancard` varchar(20) NOT NULL,
  `status` enum('I','A') NOT NULL,
  `paystatus` enum('I','A') NOT NULL,
  `epin` varchar(50) NOT NULL,
  `date` varchar(10) NOT NULL,
  `approved` varchar(10) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_member`
--

INSERT INTO `or_member` (`id`, `userid`, `username`, `sponsor`, `sponpos`, `placement`, `position`, `package`, `carrerplan`, `password`, `name`, `email`, `phone`, `address`, `bname`, `branch`, `accname`, `accno`, `usdtwallet`, `minerincome`, `ifscode`, `aadhar`, `pancard`, `status`, `paystatus`, `epin`, `date`, `approved`, `datetime`) VALUES
(93, 'MRMS7737111', 'investor', '', '', '', '', '', 'None', 'MTIzNDU2', 'MetaInv Investor', 'info@teslagateway.com', '1234567890', '3/345 Delhi Newyork', 'DD', 'Munirka Delhi', 'Murat', '', '544444444444444444444', '0', 'MBIK542512NHw', '456253521254', 'AGDPVH675N1', 'A', 'A', '', '2020-11-30', '2020-11-30', '2022-05-15 10:38:53'),
(159, 'MFEST8364144', 'sefer21', 'MRMS7737111', '', 'MRMS7737111', 'Left', '', 'None', 'ZmVzdC4yMQ==', 'MetaInv Register', 'seferocal@gmail.com', '(90-533) 402-35-21', 'Istanbul', '', '', '', '', '', '310', '', '', '', 'A', 'A', '1C5CD07FAD9FB83', '2021-08-12', '2021-08-12', '2022-05-14 16:07:11'),
(160, 'MFEST9845482', 'serhat21', 'MFEST8364144', '', 'MFEST8364144', 'Left', '', 'None', 'ZmVzdC4yMQ==', 'serhat ayazgÃ¶k', 'serhatayazgok2121@gmail.com', '(90-533) 402-35-21', 'dbakÄ±r', '', '', '', '', '', '215', '', '', '', 'A', 'A', '73915A288181C1C', '2021-08-15', '2021-08-15', '2022-01-01 12:24:31'),
(161, 'MFEST9721932', 'dogan21', 'MFEST8364144', '', 'MFEST8364144', 'Right', '', 'None', 'ZmVzdC4yMQ==', 'doÄŸan Ã¶cal', 'doganocal2121@gmail.com', '(90-533) 402-35-21', 'yenÄ±sehÄ±r', '', '', '', '', '1JgsQ5rmNbbaXYQY1xcUpDAHkAScLrhn9P', '310', '', '', '', 'A', 'A', 'D4D86AC1BE68B8D', '2021-08-12', '2021-08-12', '2022-05-12 21:00:00'),
(162, 'MFEST7028066', 'kalkan210', 'MFEST8364144', '', 'MFEST9845482', 'Left', '', 'None', 'MzMzLg==', 'aytekin oruÃ§', 'orucgida.21@hotmail.com', '9053369123', 'yenÄ±sehir', '', '', '', '', '1', '99', '', '', '', 'A', 'A', '790F9758A4252E0', '2021-08-17', '2021-08-17', '2022-11-08 12:32:55'),
(163, 'MFEST6513325', 'umutaslan21', 'MFEST8364144', '', 'MFEST9721932', 'Right', '', '', 'MzMzLg==', 'umut aslan', 'umuto2134@gmail.com', '(90-544) 252-21-08', '', '', '', '', '', '', '', '', '', '', 'A', 'A', '8CD4BC7E33BA4BC', '2021-10-24', '2021-08-14', '2022-05-13 17:35:48'),
(164, 'MFEST3003604', 'umutbey', 'MFEST8364144', '', 'MFEST6513325', 'Right', '', '', 'MzMzLg==', 'vahit ortaÃ§', 'vahitbey342102@gmail.com', '(90-533) 256-89-03', '', '', '', '', '', '', '', '', '', '', 'A', 'A', '85D71FD3D8A82B2', '2021-08-14', '2021-08-14', '2022-05-13 17:38:53'),
(165, 'MFEST4171836', 'abdullah21', 'MFEST8364144', '', 'MFEST3003604', 'Right', '', 'None', 'QXBvWC4yMDIx', 'abdullah atay', 'aatay1021@gmail.com', '(90-533) 067-06-98', '1', '', '', '', '', '1', '135', '', '', '', 'A', 'A', '71921C469144454', '2021-08-15', '2021-08-15', '2022-05-13 20:07:00'),
(166, 'MFEST8570054', 'morcicek10', 'MFEST4171836', '', 'MFEST4171836', 'Left', '', 'None', 'c203ODI4Njc=', 'samet morcicek', 'allinmor2020@gmail.com', '(90-543) 865-89-06', '1', '', '', '', '', '1', '115', '', '', '', 'A', 'A', '12ABD5D8A901BD7', '2021-09-14', '2021-09-14', '2022-05-13 12:18:57'),
(167, 'MFEST8019211', 'mahmut10', 'MFEST8570054', '', 'MFEST8570054', 'Left', '', 'None', 'MTQ1M21obVQ=', 'mahmut alpkaya', 'mahoalpkaya@gmail.com', '(90-536) 316-25-42', '.', '', '', '', '', '2000', '63', '', '', '', 'A', 'A', 'D933266C43D41D0', '2021-09-27', '2021-09-27', '2022-05-13 12:16:58'),
(168, 'MFEST6302611', 'murat21', 'MFEST8364144', '', 'MFEST4171836', 'Right', '', '', 'MzMzLg==', 'murat kaplan', 'kaplanmurat3537@gmail.com', '(90-536) 695-05-36', '', '', '', '', '', '', '', '', '', '', 'A', 'A', 'C52AA0A2A2E8F4F', '2021-08-27', '2021-08-27', '2022-05-13 18:14:00'),
(169, 'MFEST6477979', 'fujian21', 'MFEST9721932', '', 'MFEST9721932', 'Left', '', 'None', 'MzMzLmZlc3QyMQ==', 'ali salarhan', 'asalarhan@gmail.com', '(90-538) 639-27-90', '.', '', '', '', '', 'S', '125', '', '', '', 'A', 'A', '8D53F1B5566BE1F', '2021-08-19', '2021-08-19', '2022-05-13 12:19:23'),
(170, 'MFEST6805897', 'ayaz21', 'MFEST9721932', '', 'MFEST6477979', 'Left', '', '', 'MzMzLg==', 'ayaz elbilek', 'elbilekoglu3433@gmail.com', '(90-536) 564-21-87', '', '', '', '', '', '', '', '', '', '', 'A', 'A', '85589A8285BB58D', '2021-08-20', '2021-08-20', '2022-05-13 15:43:21'),
(171, 'MFEST6299914', 'vedatkaplan', 'MFEST9721932', '', 'MFEST6805897', 'Left', '', '', 'MzMzLg==', 'vedat kaplan', 'kaplanvedat198721', '(90-542) 265-32-66', '', '', '', '', '', '', '', '', '', '', 'A', 'A', '73D072E4270DD34', '2021-10-25', '2021-10-25', '2022-05-13 15:46:07'),
(173, 'MFEST7024248', 'nurikoyuncu', 'MFEST9845482', '', 'MFEST9845482', 'Right', '', '', 'MzMzLg==', 'nuri koyuncu', 'nuriikoyuncu2121@gmail.com', '(90-532) 584-00-36', '', '', '', '', '', '', '', '', '', '', 'A', 'A', 'B294BDEB434408B', '2021-10-29', '2021-10-29', '2022-05-13 09:50:13'),
(174, 'MFEST1785700', 'azizsahin', 'MFEST9845482', '', 'MFEST7024248', 'Right', '', '', 'MzMzLg==', 'aziz ÅŸahin', 'azzshn2121@gmail.com', '(90-535) 669-12-34', '', '', '', '', '', '', '', '', '', '', 'A', 'A', '96E453D07340532', '2021-11-03', '2021-11-03', '2022-05-13 10:39:31'),
(175, 'MFEST7513921', 'harunyuksel21', 'MFEST7024248', '', 'MFEST7024248', 'Left', '', '', 'MzMzLg==', 'harun yÃ¼ksel', 'harunoto3421@gmail.com', '(90-544) 369-52-78', '', '', '', '', '', '', '', '', '', '', 'A', 'A', '82208499B146864', '2021-11-03', '2021-11-03', '2022-05-13 10:43:02'),
(176, 'MFEST2290083', 'nusretbilgin21', 'MFEST7024248', '', 'MFEST7513921', 'Left', '', '', 'MzMzLg==', 'nusret bilgin', 'bilginhoca2121@gmail.com', '(90-505) 562-12-35', '', '', '', '', '', '', '', '', '', '', 'A', 'A', '2959C952D9AB882', '2021-11-03', '2021-11-03', '2021-11-03 10:46:59'),
(177, 'MFEST2435084', 'mazlumkÄ±nÄ±k34', 'MFEST6513325', '', 'MFEST6513325', 'Left', '', '', 'MzMzLg==', 'mazlum kÄ±nÄ±k', 'mazlumoto2134@gmail.com', '(90-506) 221-78-36', '', '', '', '', '', '', '', '', '', '', 'A', 'A', '253A6AD5836D3C0', '2021-11-03', '2021-11-03', '2021-11-03 10:50:48'),
(178, 'MFEST7351181', 'mikailkalayci12', 'MFEST3003604', '', 'MFEST3003604', 'Left', '', '', 'MzMzLg==', 'mikail kalayci', 'kalaycilar3434@gmail.com', '(90-545) 256-89-88', '', '', '', '', '', '', '', '', '', '', 'A', 'A', '3F0B40D4BE8AB11', '2021-11-03', '2021-11-03', '2021-11-03 10:54:03'),
(179, 'MFEST1367439', 'kÄ±smetyuksel', 'MFEST7513921', '', 'MFEST7513921', 'Right', '', '', 'MzMzLg==', 'kÄ±smet yÃ¼ksel', 'yukseloto3421@gmail.com', '(90-532) 650-36-21', '', '', '', '', '', '', '', '', '', '', 'A', 'A', 'B898FA3F7011E06', '2021-11-03', '2021-11-03', '2021-11-03 10:56:51'),
(181, 'MFEST5676467', 'kalkan21', 'MFEST7028066', '', 'MFEST7028066', 'Right', '', 'None', 'MjU4MGthbGthbg==', 'necmettin kalkan', 'guven.tur@hotmail.com', '(90-532) 278-33-36', 'yenisehir', '', '', '', '', 'TGE34HcrCekc7gLXnJQyesojHvtYfTAeFc', '156', '', '', '', 'A', 'A', 'F3308A57CF2A142', '2021-08-17', '2021-08-17', '2022-01-01 12:16:15'),
(182, 'MFEST8423036', 'caferhoca', 'MFEST8364144', '', 'MFEST7028066', 'Left', '', 'None', 'MTIzNDU2', 'cafer Ã¶ztÃ¼rk', 'caferhoca2147@gmail.com', '(90-542) 635-50-01', 'Jsksks', '', '', '', '', 'TDFDDfke2X9EiujSHbzNRRNgPczdx7WUdR', '180', '', '', '', 'A', 'A', '58BA328DF098C52', '2021-11-20', '2021-11-20', '2022-01-01 12:19:43'),
(183, 'MFEST7364342', 'recephoca', 'MFEST8423036', '', 'MFEST8423036', 'Left', '', 'None', 'MTIzNDU2', 'recep araz', 'receparaz2147@gmail.com', '(90-532) 700-90-36', '.', '', '', '', '', 'TDFDDfke2X9EiujSHbzNRRNgPczdx7WUdR', '180', '', '', '', 'A', 'A', '4BDE5E05386E8D0', '2021-11-20', '2021-11-20', '2022-01-01 12:22:40'),
(184, 'MFEST7708616', 'Medeni21', 'MFEST8364144', '', 'MFEST7364342', 'Left', '', '', 'MzMzLg==', 'Medeni demirkol', 'medeni17demir@gmail.com', '5385624576', '', '', '', '', '', '', '', '', '', '', 'A', 'A', '78CBBD06D767E24', '2021-11-22', '2021-11-22', '2021-11-22 15:07:51'),
(185, 'META5219779', 'Mirza21', 'MFEST8364144', '', 'MFEST7708616', 'Left', '', '', 'MzMzLg==', 'Mirza ayazgÃ¶k', 'Mirza33344@gmail.com', '905426355001', '', '', '', '', '', '', '', '', '', '', 'A', 'A', '58A29257C27E7E5', '2021-11-25', '2021-11-25', '2022-05-14 10:30:01'),
(188, 'META6176328', 'teslaBgroum', 'MFEST8364144', '', '', 'Left', '', '', 'MTIzNDU2', 'Tester', 'info@teslagateway.com.tr', '90542365220', '', '', '', '', '', '', '', '', '', '', 'A', 'I', '', '2022-05-14', '', '2022-05-14 17:52:48'),
(186, 'Meta8589744', '', 'MFEST7708616', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'A', 'I', '', '2022-05-14', '', '2022-05-14 02:14:19'),
(187, 'META6489489', 'suat', 'MFEST5219779', '', '', 'Right', '', '', 'MTIzNDU2', 'Suat Karaytu', 'suat@teslagetway.com', '905301392568', '', '', '', '', '', '', '', '', '', '', 'A', 'I', '', '2022-05-14', '', '2022-05-14 02:30:38');

-- --------------------------------------------------------

--
-- Table structure for table `or_member_count`
--

CREATE TABLE `or_member_count` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `left` int(11) NOT NULL,
  `right` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_member_count`
--

INSERT INTO `or_member_count` (`id`, `userid`, `left`, `right`, `datetime`) VALUES
(51, 'MRMS7737111', 25, 0, '2021-11-25 06:54:31'),
(124, 'MFEST8364144', 12, 12, '2021-11-25 06:54:31'),
(125, 'MFEST9845482', 6, 5, '2021-11-25 06:54:31'),
(126, 'MFEST9721932', 3, 8, '2021-11-03 10:54:03'),
(127, 'MFEST7028066', 4, 1, '2021-11-25 06:54:31'),
(128, 'MFEST6513325', 1, 6, '2021-11-03 10:54:03'),
(129, 'MFEST3003604', 1, 4, '2021-11-03 10:54:03'),
(130, 'MFEST4171836', 2, 1, '2021-10-24 18:14:00'),
(131, 'MFEST8570054', 1, 0, '2021-10-24 18:10:09'),
(132, 'MFEST8019211', 0, 0, '2021-10-24 18:10:09'),
(133, 'MFEST6302611', 0, 0, '2021-10-24 18:14:00'),
(134, 'MFEST6477979', 2, 0, '2021-10-25 15:46:07'),
(135, 'MFEST6805897', 1, 0, '2021-10-25 15:46:07'),
(136, 'MFEST6299914', 0, 0, '2021-10-25 15:46:07'),
(137, 'MFEST7024248', 3, 1, '2021-11-03 10:56:51'),
(138, 'MFEST1785700', 0, 0, '2021-11-03 10:39:31'),
(139, 'MFEST7513921', 1, 1, '2021-11-03 10:56:51'),
(140, 'MFEST2290083', 0, 0, '2021-11-03 10:46:59'),
(141, 'MFEST2435084', 0, 0, '2021-11-03 10:50:48'),
(142, 'MFEST7351181', 0, 0, '2021-11-03 10:54:03'),
(143, 'MFEST1367439', 0, 0, '2021-11-03 10:56:51'),
(144, 'MFEST5676467', 0, 0, '2021-11-20 12:27:50'),
(145, 'MFEST8423036', 3, 0, '2021-11-25 06:54:31'),
(146, 'MFEST7364342', 2, 0, '2021-11-25 06:54:31'),
(147, 'MFEST7708616', 1, 0, '2021-11-25 06:54:31'),
(148, 'MFEST5219779', 0, 0, '2021-11-25 06:54:31');

-- --------------------------------------------------------

--
-- Table structure for table `or_member_count_pair`
--

CREATE TABLE `or_member_count_pair` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `left` int(11) NOT NULL,
  `right` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_member_count_pair`
--

INSERT INTO `or_member_count_pair` (`id`, `userid`, `left`, `right`, `datetime`) VALUES
(51, 'MRMS7737111', 25, 0, '2021-11-25 06:54:31'),
(124, 'MFEST8364144', 12, 12, '2021-11-25 06:54:31'),
(125, 'MFEST9845482', 6, 5, '2021-11-25 06:54:31'),
(126, 'MFEST9721932', 3, 8, '2021-11-03 10:54:03'),
(127, 'MFEST7028066', 4, 1, '2021-11-25 06:54:31'),
(128, 'MFEST6513325', 1, 6, '2021-11-03 10:54:03'),
(129, 'MFEST3003604', 1, 4, '2021-11-03 10:54:03'),
(130, 'MFEST4171836', 2, 1, '2021-10-24 18:14:00'),
(131, 'MFEST8570054', 1, 0, '2021-10-24 18:10:09'),
(132, 'MFEST8019211', 0, 0, '2021-10-24 18:10:09'),
(133, 'MFEST6302611', 0, 0, '2021-10-24 18:14:00'),
(134, 'MFEST6477979', 2, 0, '2021-10-25 15:46:07'),
(135, 'MFEST6805897', 1, 0, '2021-10-25 15:46:07'),
(136, 'MFEST6299914', 0, 0, '2021-10-25 15:46:07'),
(137, 'MFEST7024248', 3, 1, '2021-11-03 10:56:51'),
(138, 'MFEST1785700', 0, 0, '2021-11-03 10:39:31'),
(139, 'MFEST7513921', 1, 1, '2021-11-03 10:56:51'),
(140, 'MFEST2290083', 0, 0, '2021-11-03 10:46:59'),
(141, 'MFEST2435084', 0, 0, '2021-11-03 10:50:48'),
(142, 'MFEST7351181', 0, 0, '2021-11-03 10:54:03'),
(143, 'MFEST1367439', 0, 0, '2021-11-03 10:56:51'),
(144, 'MFEST5676467', 0, 0, '2021-11-20 12:27:50'),
(145, 'MFEST8423036', 3, 0, '2021-11-25 06:54:31'),
(146, 'MFEST7364342', 2, 0, '2021-11-25 06:54:31'),
(147, 'MFEST7708616', 1, 0, '2021-11-25 06:54:31'),
(148, 'MFEST5219779', 0, 0, '2021-11-25 06:54:31');

-- --------------------------------------------------------

--
-- Table structure for table `or_member_epin`
--

CREATE TABLE `or_member_epin` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `noepin` int(11) NOT NULL,
  `pvalue` double(15,2) NOT NULL,
  `epincost` double(15,2) NOT NULL,
  `charge` double(15,2) NOT NULL,
  `total` double(15,2) NOT NULL,
  `date` varchar(10) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `or_member_payment`
--

CREATE TABLE `or_member_payment` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `amount` double(15,2) NOT NULL,
  `packid` varchar(100) NOT NULL,
  `tranid` varchar(50) NOT NULL,
  `slip` varchar(250) NOT NULL,
  `status` enum('P','C') NOT NULL,
  `date` varchar(10) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_member_payment`
--

INSERT INTO `or_member_payment` (`id`, `userid`, `amount`, `packid`, `tranid`, `slip`, `status`, `date`, `datetime`) VALUES
(24, 'MRMS8581107', 1000.00, '8', '19464646464646', '37707pulse dedektör.jpg', '', '2021-10-03', '2021-10-18 13:12:40'),
(43, 'MRMS7249685', 250.00, '2', '6265655656232', '605408243400265_4750962544936280_9001166154239203904_n (1) (1).jpg', '', '2021-10-05', '2021-10-18 13:12:40'),
(25, 'MRMS8171271', 1000.00, '8', '19666448484', '164361Logo.png', '', '2021-10-03', '2021-10-18 13:12:40'),
(26, 'MRMS2296539', 250.00, '2', '45646das6das', '913022b?nance.png', '', '2021-10-03', '2021-10-18 13:12:40'),
(27, 'MRMS4665829', 500.00, '3', '45646das6das554', '435224b?nance.png', '', '2021-10-03', '2021-10-18 13:12:40'),
(28, 'MRMS4197972', 500.00, '3', '45646das6das', '493938b?nance.png', '', '2021-10-03', '2021-10-18 13:12:40'),
(29, 'MRMS4523265', 500.00, '3', '6265655656', '501154WhatsApp Image 2021-09-29 at 9.14.03 PM.jpg', '', '2021-10-03', '2021-10-18 13:12:40'),
(30, 'MRMS4789056', 1000.00, '3', '6265655656c', '972658WhatsApp Image 2021-09-29 at 9.14.03 PM.jpg', '', '2021-10-03', '2021-10-18 13:12:40'),
(31, 'MRMS7508670', 500.00, '3', '545454948s', '166245WhatsApp Image 2021-09-29 at 9.14.03 PM (2).jpg', '', '2021-10-03', '2021-10-18 13:12:40'),
(32, 'MRMS5718657', 4000.00, '5', '6265655656656', '61507WhatsApp Image 2021-09-29 at 9.14.03 PM (1).jpg', '', '2021-10-03', '2021-10-18 13:12:40'),
(33, 'MRMS6565541', 4000.00, '5', '6265655656878', '470861WhatsApp Image 2021-09-29 at 9.14.03 PM (2).jpg', '', '2021-10-03', '2021-10-18 13:12:40'),
(34, 'MRMS8658582', 4000.00, '5', '626565565695997878', '367162501154WhatsApp Image 2021-09-29 at 9.14.03 PM.jpg', '', '2021-10-04', '2021-10-18 13:12:40'),
(35, 'MRMS7021650', 4000.00, '5', '626565565663232323', '217096WhatsApp Image 2021-09-24 at 10.04.29 PM (1) (1).jpg', '', '2021-10-04', '2021-10-18 13:12:40'),
(36, 'MRMS5062882', 4000.00, '5', '6265655656959978787', '540753243400265_4750962544936280_9001166154239203904_n (1) (1).jpg', '', '2021-10-05', '2021-10-18 13:12:40'),
(37, 'MRMS7289867', 4000.00, '5', '626565565687812', '343537501154WhatsApp Image 2021-09-29 at 9.14.03 PM.jpg', '', '2021-10-05', '2021-10-18 13:12:40'),
(38, 'MRMS8906844', 4000.00, '5', '626565565665656', '415913501154WhatsApp Image 2021-09-29 at 9.14.03 PM.jpg', '', '2021-10-05', '2021-10-18 13:12:40'),
(39, 'MRMS7411809', 4000.00, '2', '626565565634556', '49069501154WhatsApp Image 2021-09-29 at 9.14.03 PM.jpg', '', '2021-10-05', '2021-10-18 13:12:40'),
(40, 'MRMS9245134', 4000.00, '5', '62656556561', '978285501154WhatsApp Image 2021-09-29 at 9.14.03 PM.jpg', '', '2021-10-05', '2021-10-18 13:12:40'),
(41, 'MRMS4176554', 4000.00, '5', '62656556569878788', '455579501154WhatsApp Image 2021-09-29 at 9.14.03 PM.jpg', '', '2021-10-05', '2021-10-18 13:12:40'),
(42, 'MRMS1476634', 500.00, '3', '6265655656c', '877667501154WhatsApp Image 2021-09-29 at 9.14.03 PM.jpg', '', '2021-10-05', '2021-10-18 13:12:40'),
(44, 'MRMS7829268', 500.00, '3', '62656556569898', '682280WhatsApp Image 2021-09-29 at 9.14.03 PM.jpg', '', '2021-10-05', '2021-10-18 13:12:40'),
(45, 'MRMS6270618', 500.00, '3', '626565565699', '454449WhatsApp Image 2021-09-29 at 9.14.03 PM.jpg', '', '2021-10-05', '2021-10-18 13:12:40'),
(46, 'MRMS1410631', 1000.00, '8', '6265655656656', '732746WhatsApp Image 2021-09-29 at 9.14.04 PM.jpeg', '', '2021-10-05', '2021-10-18 13:12:40'),
(47, 'MRMS8918263', 2000.00, '4', '62656556561213231', '979245WhatsApp Image 2021-09-24 at 10.04.29 PM (1).jpg', '', '2021-10-05', '2021-10-18 13:12:40'),
(48, 'MFEST8364144', 1000.00, '4', '556612123', '646757bÄ±nance.png', '', '2021-10-20', '2021-10-20 18:27:36'),
(49, 'MFEST9845482', 1000.00, '4', 'bbjknÃ¶53322123', '377223bÄ±nance.png', '', '2021-10-22', '2021-10-22 14:14:20'),
(50, 'MFEST9721932', 1000.00, '4', 'dsadsaddsadsa', '226601bÄ±nance.png', '', '2021-10-22', '2021-10-24 17:28:05'),
(51, 'MFEST7028066', 1000.00, '4', '11', '99820mavi.png', '', '2021-10-24', '2021-10-24 17:28:08'),
(52, 'MFEST6513325', 1000.00, '4', '11', '310596mavi.png', '', '2021-10-24', '2021-10-24 17:35:01'),
(53, 'MFEST3003604', 1000.00, '4', '11', '751419mavi.png', '', '2021-10-24', '2021-10-24 17:37:45'),
(54, 'MFEST4171836', 1000.00, '4', '11', '307905mavi.png', '', '2021-10-24', '2021-10-24 17:42:04'),
(55, 'MFEST8570054', 1000.00, '4', '11', '737457mavi.png', '', '2021-10-24', '2021-10-24 17:55:35'),
(56, 'MFEST8019211', 1000.00, '4', '11', '837563mavi.png', '', '2021-10-24', '2021-10-24 18:09:37'),
(57, 'MFEST6302611', 1000.00, '4', '11', '13928mavi.png', '', '2021-10-24', '2021-10-24 18:13:18'),
(58, 'MFEST6477979', 1000.00, '4', '11', '54662mavi.png', '', '2021-10-24', '2021-10-24 18:41:05'),
(59, 'MFEST6805897', 1000.00, '4', '11', '576640mavi.png', '', '2021-10-25', '2021-10-25 15:42:51'),
(60, 'MFEST6299914', 1000.00, '4', '11', '68123mavi.png', '', '2021-10-25', '2021-10-25 15:45:35'),
(61, 'MFEST7024248', 1000.00, '4', '1', '188348mavi.png', '', '2021-10-29', '2021-10-29 09:49:28'),
(62, 'MFEST1785700', 1000.00, '4', '1', '268889mavi.png', '', '2021-11-03', '2021-11-03 10:38:58'),
(63, 'MFEST7513921', 1000.00, '4', '1', '11095mavi.png', '', '2021-11-03', '2021-11-03 10:42:21'),
(64, 'MFEST2290083', 1000.00, '4', '1', '363216mavi.png', '', '2021-11-03', '2021-11-03 10:46:28'),
(65, 'MFEST2435084', 1000.00, '4', '1', '863884mavi.png', '', '2021-11-03', '2021-11-03 10:50:21'),
(66, 'MFEST7351181', 1000.00, '4', '1', '993917mavi.png', '', '2021-11-03', '2021-11-03 10:53:38'),
(67, 'MFEST1367439', 1000.00, '4', '1', '624123mavi.png', '', '2021-11-03', '2021-11-03 10:56:26'),
(68, 'MFEST5676467', 1000.00, '4', '1', '597907mavi.png', '', '2021-11-20', '2021-11-20 12:27:25'),
(69, 'MFEST8423036', 2000.00, '5', '1', '846384mavi.png', '', '2021-11-20', '2021-11-20 12:41:21'),
(70, 'MFEST7364342', 2000.00, '5', '1', '924747mavi.png', '', '2021-11-20', '2021-11-20 12:47:25'),
(71, 'MFEST7708616', 1000.00, '4', '1', '380666FB_IMG_1636972395221.jpg', '', '2021-11-22', '2021-11-22 15:07:11'),
(72, 'MFEST5219779', 500.00, '3', '1', '937393IMG-20211124-WA0005.jpg', '', '2021-11-25', '2021-11-25 06:53:50');

-- --------------------------------------------------------

--
-- Table structure for table `or_member_recharge`
--

CREATE TABLE `or_member_recharge` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `orderid` varchar(30) NOT NULL,
  `operator` varchar(30) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `amount` double(15,2) NOT NULL,
  `charge` double(15,2) NOT NULL,
  `total` double(15,2) NOT NULL,
  `status` varchar(30) NOT NULL,
  `txnid` varchar(50) NOT NULL,
  `joloorderid` varchar(50) NOT NULL,
  `servicetype` varchar(50) NOT NULL,
  `error` text NOT NULL,
  `date` varchar(10) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `or_member_sales`
--

CREATE TABLE `or_member_sales` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `left` double(15,2) NOT NULL,
  `right` double(15,2) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_member_sales`
--

INSERT INTO `or_member_sales` (`id`, `userid`, `left`, `right`, `datetime`) VALUES
(51, 'MRMS7737111', 2650.00, 0.00, '2021-11-25 06:54:31'),
(124, 'MFEST8364144', 150.00, 0.00, '2021-11-25 06:54:31'),
(125, 'MFEST9845482', 250.00, 0.00, '2021-11-25 06:54:31'),
(126, 'MFEST9721932', 0.00, 500.00, '2021-11-03 10:54:03'),
(127, 'MFEST7028066', 450.00, 0.00, '2021-11-25 06:54:31'),
(128, 'MFEST6513325', 0.00, 500.00, '2021-11-03 10:54:03'),
(129, 'MFEST3003604', 0.00, 300.00, '2021-11-03 10:54:03'),
(130, 'MFEST4171836', 100.00, 0.00, '2021-10-24 18:14:00'),
(131, 'MFEST8570054', 100.00, 0.00, '2021-10-24 18:10:09'),
(132, 'MFEST8019211', 0.00, 0.00, '2021-10-24 18:10:09'),
(133, 'MFEST6302611', 0.00, 0.00, '2021-10-24 18:14:00'),
(134, 'MFEST6477979', 200.00, 0.00, '2021-10-25 15:46:07'),
(135, 'MFEST6805897', 100.00, 0.00, '2021-10-25 15:46:07'),
(136, 'MFEST6299914', 0.00, 0.00, '2021-10-25 15:46:07'),
(137, 'MFEST7024248', 200.00, 0.00, '2021-11-03 10:56:51'),
(138, 'MFEST1785700', 0.00, 0.00, '2021-11-03 10:39:31'),
(139, 'MFEST7513921', 0.00, 0.00, '2021-11-03 10:56:51'),
(140, 'MFEST2290083', 0.00, 0.00, '2021-11-03 10:46:59'),
(141, 'MFEST2435084', 0.00, 0.00, '2021-11-03 10:50:48'),
(142, 'MFEST7351181', 0.00, 0.00, '2021-11-03 10:54:03'),
(143, 'MFEST1367439', 0.00, 0.00, '2021-11-03 10:56:51'),
(144, 'MFEST5676467', 0.00, 0.00, '2021-11-20 12:27:50'),
(145, 'MFEST8423036', 350.00, 0.00, '2021-11-25 06:54:31'),
(146, 'MFEST7364342', 150.00, 0.00, '2021-11-25 06:54:31'),
(147, 'MFEST7708616', 50.00, 0.00, '2021-11-25 06:54:31'),
(148, 'MFEST5219779', 0.00, 0.00, '2021-11-25 06:54:31');

-- --------------------------------------------------------

--
-- Table structure for table `or_member_sales1`
--

CREATE TABLE `or_member_sales1` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `left` double(15,2) NOT NULL,
  `right` double(15,2) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_member_sales1`
--

INSERT INTO `or_member_sales1` (`id`, `userid`, `left`, `right`, `datetime`) VALUES
(103, 'MRMS7737111', 26500.00, 0.00, '2021-11-25 06:54:31'),
(125, 'MFEST8364144', 1500.00, 0.00, '2021-11-25 06:54:31'),
(126, 'MFEST9845482', 2500.00, 0.00, '2021-11-25 06:54:31'),
(127, 'MFEST9721932', 0.00, 5000.00, '2021-11-03 10:54:03'),
(128, 'MFEST7028066', 4500.00, 0.00, '2021-11-25 06:54:31'),
(129, 'MFEST6513325', 0.00, 5000.00, '2021-11-03 10:54:03'),
(130, 'MFEST3003604', 0.00, 3000.00, '2021-11-03 10:54:03'),
(131, 'MFEST4171836', 1000.00, 0.00, '2021-10-24 18:14:00'),
(132, 'MFEST8570054', 1000.00, 0.00, '2021-10-24 18:10:09'),
(133, 'MFEST8019211', 0.00, 0.00, '2021-10-24 18:10:09'),
(134, 'MFEST6302611', 0.00, 0.00, '2021-10-24 18:14:00'),
(135, 'MFEST6477979', 2000.00, 0.00, '2021-10-25 15:46:07'),
(136, 'MFEST6805897', 1000.00, 0.00, '2021-10-25 15:46:07'),
(137, 'MFEST6299914', 0.00, 0.00, '2021-10-25 15:46:07'),
(138, 'MFEST7024248', 2000.00, 0.00, '2021-11-03 10:56:51'),
(139, 'MFEST1785700', 0.00, 0.00, '2021-11-03 10:39:31'),
(140, 'MFEST7513921', 0.00, 0.00, '2021-11-03 10:56:51'),
(141, 'MFEST2290083', 0.00, 0.00, '2021-11-03 10:46:59'),
(142, 'MFEST2435084', 0.00, 0.00, '2021-11-03 10:50:48'),
(143, 'MFEST7351181', 0.00, 0.00, '2021-11-03 10:54:03'),
(144, 'MFEST1367439', 0.00, 0.00, '2021-11-03 10:56:51'),
(145, 'MFEST5676467', 0.00, 0.00, '2021-11-20 12:27:50'),
(146, 'MFEST8423036', 3500.00, 0.00, '2021-11-25 06:54:31'),
(147, 'MFEST7364342', 1500.00, 0.00, '2021-11-25 06:54:31'),
(148, 'MFEST7708616', 500.00, 0.00, '2021-11-25 06:54:31'),
(149, 'MFEST5219779', 0.00, 0.00, '2021-11-25 06:54:31');

-- --------------------------------------------------------

--
-- Table structure for table `or_member_topup`
--

CREATE TABLE `or_member_topup` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `topupid` varchar(20) NOT NULL,
  `epin` varchar(50) NOT NULL,
  `date` varchar(10) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `or_settings_joining`
--

CREATE TABLE `or_settings_joining` (
  `id` int(11) NOT NULL,
  `pack_name` varchar(255) NOT NULL,
  `description` varchar(250) NOT NULL,
  `joining` double(15,2) NOT NULL,
  `bv` varchar(255) NOT NULL,
  `binary` double(15,2) NOT NULL,
  `binary1` varchar(100) NOT NULL,
  `direct` varchar(255) NOT NULL,
  `capping` double(15,2) NOT NULL,
  `recharge` double(15,2) NOT NULL,
  `nomonth` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_settings_joining`
--

INSERT INTO `or_settings_joining` (`id`, `pack_name`, `description`, `joining`, `bv`, `binary`, `binary1`, `direct`, `capping`, `recharge`, `nomonth`, `datetime`) VALUES
(2, 'NFT 1', 'A firewall gateway provides end-to-end connectivity options for environments with specific TCP/IP connection management policies. The firewall gateway can negotiate numerous firewall hops and supports network address translation.', 250.00, '25', 6.00, '25', '6', 30000.00, 50.00, 3, '2022-05-14 19:17:28'),
(3, 'NFT 2', '', 500.00, '50', 8.00, '50', '8', 30000.00, 50.00, 3, '2022-05-14 19:17:30'),
(4, 'NFT 3', '', 1000.00, '100', 10.00, '100', '10', 30000.00, 50.00, 3, '2022-05-14 19:17:34'),
(5, 'NFT 4', '', 2000.00, '200', 10.00, '200', '12', 30000.00, 50.00, 3, '2022-05-14 19:17:37'),
(8, 'NFT 5', '', 4000.00, '400', 10.00, '400', '15', 30000.00, 0.00, 3, '2022-05-14 19:17:41');

-- --------------------------------------------------------

--
-- Table structure for table `or_settings_withdrawal`
--

CREATE TABLE `or_settings_withdrawal` (
  `id` int(11) NOT NULL,
  `minimum` double(15,2) NOT NULL,
  `tds` double(15,2) NOT NULL,
  `service` double(15,2) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_settings_withdrawal`
--

INSERT INTO `or_settings_withdrawal` (`id`, `minimum`, `tds`, `service`, `datetime`) VALUES
(1, 100.00, 0.00, 0.00, '2021-10-25 18:44:07');

-- --------------------------------------------------------

--
-- Table structure for table `or_state`
--

CREATE TABLE `or_state` (
  `id` int(11) NOT NULL,
  `state` varchar(150) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_state`
--

INSERT INTO `or_state` (`id`, `state`, `datetime`) VALUES
(37, 'west bengal', '2021-10-18 13:12:41'),
(38, 'Andaman and Nicobar Islands', '2021-10-18 13:12:41'),
(39, 'Andhra Pradesh', '2021-10-18 13:12:41'),
(40, 'Arunachal Pradesh', '2021-10-18 13:12:41'),
(41, 'Assam', '2021-10-18 13:12:41'),
(42, 'Bihar', '2021-10-18 13:12:41'),
(43, 'Chandigarh', '2021-10-18 13:12:41'),
(44, 'Chhattisgarh', '2021-10-18 13:12:41'),
(45, 'Dadra and Nagar Haveli', '2021-10-18 13:12:41'),
(46, 'Daman and Diu', '2021-10-18 13:12:41'),
(47, 'Delhi', '2021-10-18 13:12:41'),
(48, 'Goa', '2021-10-18 13:12:41'),
(49, 'Gujrat', '2021-10-18 13:12:41'),
(50, 'Haryana', '2021-10-18 13:12:41'),
(51, 'Himachal Pradesh', '2021-10-18 13:12:41'),
(52, 'Jammu and Kashmir', '2021-10-18 13:12:41'),
(53, 'Jharkhand', '2021-10-18 13:12:41'),
(54, 'Karnataka', '2021-10-18 13:12:41'),
(55, 'Kerala', '2021-10-18 13:12:41'),
(56, 'Lakshadweep', '2021-10-18 13:12:41'),
(57, 'Madhya Pradesh', '2021-10-18 13:12:41'),
(58, 'Maharashtra', '2021-10-18 13:12:41'),
(59, 'Manipur', '2021-10-18 13:12:41'),
(60, 'Meghalaya', '2021-10-18 13:12:41'),
(61, 'Mizoram', '2021-10-18 13:12:41'),
(62, 'Nagaland', '2021-10-18 13:12:41'),
(63, 'Odisha', '2021-10-18 13:12:41'),
(64, 'Puducherry', '2021-10-18 13:12:41'),
(65, 'Punjab', '2021-10-18 13:12:41'),
(66, 'Rajasthan', '2021-10-18 13:12:41'),
(67, 'Sikkim', '2021-10-18 13:12:41'),
(68, 'Tamil Nadu', '2021-10-18 13:12:41'),
(69, 'Telangana', '2021-10-18 13:12:41'),
(70, 'Uttar Pradesh', '2021-10-18 13:12:41');

-- --------------------------------------------------------

--
-- Table structure for table `or_withdrawal`
--

CREATE TABLE `or_withdrawal` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `request` double(15,2) NOT NULL,
  `tds` double(15,2) NOT NULL,
  `service` double(15,2) NOT NULL,
  `payout` double(15,2) NOT NULL,
  `usdtwallet` varchar(30) NOT NULL,
  `bname` varchar(100) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `accname` varchar(30) NOT NULL,
  `accno` varchar(30) NOT NULL,
  `ifscode` varchar(30) NOT NULL,
  `status` enum('P','C') NOT NULL,
  `date` varchar(10) NOT NULL,
  `approved` varchar(10) NOT NULL,
  `paid` enum('P','C') NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `or_withdrawal`
--

INSERT INTO `or_withdrawal` (`id`, `userid`, `request`, `tds`, `service`, `payout`, `usdtwallet`, `bname`, `branch`, `accname`, `accno`, `ifscode`, `status`, `date`, `approved`, `paid`, `datetime`) VALUES
(2, 'MFEST8364144', 751.00, 0.00, 0.00, 751.00, '22151151515151', '', '', '', '', '', 'C', '2021-10-25', '2021-10-25', 'C', '2021-10-25 18:50:10'),
(3, 'MFEST8570054', 126.00, 0.00, 0.00, 126.00, '', '', '', '', '', '', 'C', '2021-10-26', '2021-10-26', 'C', '2021-10-25 19:09:47'),
(4, 'MFEST4171836', 240.00, 0.00, 0.00, 240.00, '', '', '', '', '', '', 'C', '2021-10-26', '2021-10-26', 'C', '2021-10-25 19:09:44'),
(5, 'MFEST9721932', 500.00, 0.00, 0.00, 500.00, '', '', '', '', '', '', 'C', '2021-10-26', '2021-10-26', 'C', '2021-10-25 19:09:42'),
(6, 'MFEST8364144', 800.00, 0.00, 0.00, 800.00, '', '', '', '', '', '', 'C', '2021-11-03', '2021-11-04', 'P', '2021-11-04 08:41:51'),
(7, 'MFEST9721932', 250.00, 0.00, 0.00, 250.00, '', '', '', '', '', '', 'C', '2021-11-03', '2021-11-04', 'P', '2021-11-04 08:41:48'),
(10, 'MFEST6477979', 125.00, 0.00, 0.00, 125.00, '', '', '', '', '', '', 'C', '2021-12-02', '2021-12-02', 'P', '2021-12-02 15:33:30'),
(9, 'MFEST8364144', 700.00, 0.00, 0.00, 700.00, '', '', '', '', '', '', 'C', '2021-11-20', '2021-11-20', 'P', '2021-11-20 17:20:00'),
(11, 'MFEST8423036', 285.00, 0.00, 0.00, 285.00, '', '', '', '', '', '', 'C', '2021-12-02', '2021-12-02', 'P', '2021-12-02 15:33:26'),
(12, 'MFEST8364144', 239.00, 0.00, 0.00, 239.00, '', '', '', '', '', '', 'C', '2021-12-02', '2021-12-02', 'P', '2021-12-02 16:51:12'),
(13, 'MFEST5676467', 126.00, 0.00, 0.00, 126.00, '', '', '', '', '', '', 'C', '2021-12-08', '2021-12-14', 'P', '2021-12-14 09:40:42'),
(14, 'MFEST8423036', 135.00, 0.00, 0.00, 135.00, '', '', '', '', '', '', 'C', '2022-01-01', '2022-01-01', 'P', '2022-01-01 12:22:21'),
(15, 'MFEST7364342', 180.00, 0.00, 0.00, 180.00, '', '', '', '', '', '', 'C', '2022-01-01', '2022-01-01', 'P', '2022-01-01 12:23:06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_leveincome`
--

CREATE TABLE `tbl_leveincome` (
  `id` int(11) NOT NULL,
  `userid` varchar(255) NOT NULL,
  `level_userid` varchar(255) NOT NULL,
  `sponsor_id` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `level` varchar(255) NOT NULL,
  `pakage` varchar(255) NOT NULL,
  `cdate` date NOT NULL,
  `oderid` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `direct_income`
--
ALTER TABLE `direct_income`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gm_settings_level`
--
ALTER TABLE `gm_settings_level`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `metamask`
--
ALTER TABLE `metamask`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `address` (`address`);

--
-- Indexes for table `or_admin`
--
ALTER TABLE `or_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_carrer_plan`
--
ALTER TABLE `or_carrer_plan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_commission_binary`
--
ALTER TABLE `or_commission_binary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_commission_binary_matching`
--
ALTER TABLE `or_commission_binary_matching`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_company`
--
ALTER TABLE `or_company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_deposit`
--
ALTER TABLE `or_deposit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_epin`
--
ALTER TABLE `or_epin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_genealogy`
--
ALTER TABLE `or_genealogy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_member`
--
ALTER TABLE `or_member`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_member_count`
--
ALTER TABLE `or_member_count`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_member_count_pair`
--
ALTER TABLE `or_member_count_pair`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_member_epin`
--
ALTER TABLE `or_member_epin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_member_payment`
--
ALTER TABLE `or_member_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_member_recharge`
--
ALTER TABLE `or_member_recharge`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_member_sales`
--
ALTER TABLE `or_member_sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_member_sales1`
--
ALTER TABLE `or_member_sales1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_member_topup`
--
ALTER TABLE `or_member_topup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_settings_joining`
--
ALTER TABLE `or_settings_joining`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_settings_withdrawal`
--
ALTER TABLE `or_settings_withdrawal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_state`
--
ALTER TABLE `or_state`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `or_withdrawal`
--
ALTER TABLE `or_withdrawal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_leveincome`
--
ALTER TABLE `tbl_leveincome`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `direct_income`
--
ALTER TABLE `direct_income`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `gm_settings_level`
--
ALTER TABLE `gm_settings_level`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `metamask`
--
ALTER TABLE `metamask`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `or_admin`
--
ALTER TABLE `or_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `or_carrer_plan`
--
ALTER TABLE `or_carrer_plan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `or_commission_binary`
--
ALTER TABLE `or_commission_binary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `or_commission_binary_matching`
--
ALTER TABLE `or_commission_binary_matching`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `or_company`
--
ALTER TABLE `or_company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `or_deposit`
--
ALTER TABLE `or_deposit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `or_epin`
--
ALTER TABLE `or_epin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=298;

--
-- AUTO_INCREMENT for table `or_genealogy`
--
ALTER TABLE `or_genealogy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `or_member`
--
ALTER TABLE `or_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=189;

--
-- AUTO_INCREMENT for table `or_member_count`
--
ALTER TABLE `or_member_count`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `or_member_count_pair`
--
ALTER TABLE `or_member_count_pair`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `or_member_epin`
--
ALTER TABLE `or_member_epin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `or_member_payment`
--
ALTER TABLE `or_member_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `or_member_recharge`
--
ALTER TABLE `or_member_recharge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `or_member_sales`
--
ALTER TABLE `or_member_sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `or_member_sales1`
--
ALTER TABLE `or_member_sales1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT for table `or_member_topup`
--
ALTER TABLE `or_member_topup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `or_settings_joining`
--
ALTER TABLE `or_settings_joining`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `or_settings_withdrawal`
--
ALTER TABLE `or_settings_withdrawal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `or_state`
--
ALTER TABLE `or_state`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `or_withdrawal`
--
ALTER TABLE `or_withdrawal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_leveincome`
--
ALTER TABLE `tbl_leveincome`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
