<?php
session_start();
include('includes/function.php');
if(!isset($_SESSION['sid']))
{
redirect('index.php');
}

if($_SESSION['sid'])
{
if($_REQUEST['case']=='edit')
{ 

  $sql1="UPDATE `or_settings_joining` SET `pack_name`='".mysqli_escape_string($conn,$_POST['pack_name'])."', `joining`='".mysqli_escape_string($conn,$_POST['joining'])."',`bv`='".mysqli_escape_string($conn,$_POST['bv'])."',`binary`='".mysqli_escape_string($conn,$_POST['binary'])."',`binary1`='".mysqli_escape_string($conn,$_POST['binary1'])."',`direct`='".mysqli_escape_string($conn,$_POST['direct'])."',`capping`='".mysqli_escape_string($conn,$_POST['capping'])."'  WHERE `id`='".mysqli_escape_string($conn,$_REQUEST['id'])."'";




$res1=query($conn,$sql1);
 
redirect('settings-joining.php');
}

if($_REQUEST['case']=='add')
{ 

 $sql1="INSERT INTO `or_settings_joining` (`pack_name`, `joining`, `bv`, `binary`, `binary1`, `direct`, `capping`) VALUES ('".mysqli_escape_string($conn,$_POST['pack_name'])."', '".mysqli_escape_string($conn,$_POST['joining'])."', '".mysqli_escape_string($conn,$_POST['bv'])."', '".mysqli_escape_string($conn,$_POST['binary'])."' ,'".mysqli_escape_string($conn,$_POST['binary1'])."','".mysqli_escape_string($conn,$_POST['direct'])."','".mysqli_escape_string($conn,$_POST['capping'])."')";   

$res1=query($conn,$sql1); 
 
redirect('settings-joining.php?m=3');
}
 


}
?> 