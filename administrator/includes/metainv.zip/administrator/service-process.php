<?php
session_start();
include('includes/function.php');

if($_REQUEST['case']=='add')
{

$sql="SELECT * FROM `or_recharge_service` WHERE `service`='".mysqli_real_escape_string($conn,$_POST['service'])."'";
$res=query($conn,$sql);
$num=numrows($res);
if($num>0)
{  
redirect('service.php?case=add&m=1');
}else{
$sql="INSERT INTO `or_recharge_service` (`service`) VALUES ('".mysqli_real_escape_string($conn,$_POST['service'])."')";
$res=query($conn,$sql);
redirect('service.php?case=add&m=2');
}
}

if($_REQUEST['case']=='edit')

{

$sql="SELECT * FROM `or_recharge_service` WHERE `service`='".mysqli_real_escape_string($conn,$_POST['service'])."'";
$res=query($conn,$sql);
$num=numrows($res);
if($num>0)
{
redirect('service.php?case=edit&e=1');
}else
{
$sql1="UPDATE `or_recharge_service` SET `service`='".trim(mysqli_real_escape_string($conn,$_POST['service']))."' WHERE `id`='".mysqli_real_escape_string($conn,$_REQUEST['id'])."'";
$res1=query($conn,$sql1);

redirect('service.php?m=1');
}
}



if($_REQUEST['case']=='delete')
{
$sql="DELETE FROM `or_recharge_service`  WHERE `id`='".mysqli_real_escape_string($conn,$_REQUEST['id'])."'";
$res=query($conn,$sql); 


redirect('service.php?page='.$_REQUEST['page']);
}

?>