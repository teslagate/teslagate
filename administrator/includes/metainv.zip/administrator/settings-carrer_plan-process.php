<?php
session_start();
include('includes/function.php');
if(!isset($_SESSION['sid']))
{
redirect('index.php');
}

if($_SESSION['sid'])
{
if($_REQUEST['case']=='edit')
{ 

  $sql1="UPDATE `or_carrer_plan` SET `pack_name`='".mysqli_escape_string($conn,$_POST['pack_name'])."', `joining`='".mysqli_escape_string($conn,$_POST['joining'])."',`bv`='".mysqli_escape_string($conn,$_POST['bv'])."'  WHERE `id`='".mysqli_escape_string($conn,$_REQUEST['id'])."'";

  


$res1=query($conn,$sql1);
 
redirect('settings-carrer_plan.php');
}

if($_REQUEST['case']=='add')
{ 

 $sql1="INSERT INTO `or_carrer_plan` (`pack_name`, `joining`, `bv`) VALUES ('".mysqli_escape_string($conn,$_POST['pack_name'])."', '".mysqli_escape_string($conn,$_POST['joining'])."', '".mysqli_escape_string($conn,$_POST['bv'])."')";   

$res1=query($conn,$sql1); 
 
redirect('settings-carrer_plan.php?m=3');
}
 


}
?> 