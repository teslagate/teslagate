<?php
session_start();
include('includes/function.php');
if(!isset($_SESSION['sid']))
{
redirect('index.php');
}

if($_SESSION['sid'])
{
if($_REQUEST['case']=='status')
{
echo $sql="UPDATE `or_member_recharge` SET `status`='S' WHERE `id`='".mysqli_real_escape_string($conn,$_REQUEST['id'])."'";
$res=query($conn,$sql);

redirect('view-recharge.php?page='.mysqli_real_escape_string($conn,$_REQUEST['page']));
}


}
?>