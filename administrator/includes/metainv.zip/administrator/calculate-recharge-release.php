<?php
$userid=getMember($conn,$_SESSION['mid'],'userid');

$sqlr="SELECT * FROM `or_commission_recharge` WHERE `userid`='".$userid."' AND `status`='H' AND `date`<='".date('Y-m-d')."'";
$resr=query($conn,$sqlr);
$numr=numrows($resr);
if($numr>0)
{
while($fetchr=fetcharray($resr))
{
$sqlr2="UPDATE `or_commission_recharge` SET `status`='R' WHERE `userid`='".$userid."' AND `id`='".$fetchr['id']."'";
$resr2=query($conn,$sqlr2);
}
}
?> 