<div data-scroll-to-active="true" class="main-menu menu-fixed menu-dark menu-accordion menu-shadow">
<div class="main-menu-content">
<ul id="main-menu-navigation" data-menu="menu-navigation" class="navigation navigation-main">
<li class=" nav-item"><a href="dashboard.php"><i class="icon-home3"></i><span data-i18n="nav.dash.main" class="Home">Home</span></a>
</li>

<li class=" nav-item"><a href="#"><i class="icon-gear"></i><span data-i18n="nav.dash.main" class="Settings">Settings</span></a>
<ul class="menu-content">

<li class="<?php if($left=='2'){?> active<?php }?>"><a href="settings-joining.php?case=add" data-i18n="nav.dash.main" class="menu-item"><i class="icon-arrow-right3"></i> Add Plan</a></li>

<li class="<?php if($left=='2'){?> active<?php }?>"><a href="settings-carrer_plan.php?case=add" data-i18n="nav.dash.main" class="menu-item"><i class="icon-arrow-right3"></i>Carrer Add Plan</a></li>


<li class="<?php if($left=='2'){?> active<?php }?>"><a href="settings-joining.php" data-i18n="nav.dash.main" class="menu-item"><i class="icon-arrow-right3"></i>View Plan</a></li>

<li class="<?php if($left=='2'){?> active<?php }?>"><a href="settings-carrer_plan.php" data-i18n="nav.dash.main" class="menu-item"><i class="icon-arrow-right3"></i>Carrer View Plan</a></li>

<li class="<?php if($left=='2'){?> active<?php }?>"><a href="settings-withdrawal.php" data-i18n="nav.dash.main" class="menu-item"><i class="icon-arrow-right3"></i>Withdrawal</a></li>

 
</ul>
</li>
<li class=" nav-item"><a href="#"><i class="icon-group"></i><span data-i18n="nav.dash.main" class="Member">Member</span></a>
<ul class="menu-content">
<?php if(getTotalMember($conn)<1){ ?>
<li class="<?php if($left=='3'){?> active<?php }?>"><a href="member.php?case=add" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>First Member</a></li>
<?php }?>
<li class="<?php if($left=='3'){?> active<?php }?>"><a href="member.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>View Member</a></li>
<li class="<?php if($left=='3'){?> active<?php }?>"><a href="bank-details.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>Bank Details</a></li>
<li class="<?php if($left=='3'){?> active<?php }?>"><a href="income-statement.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>Income Statement</a></li>
<li class="<?php if($left=='3'){?> active<?php }?>"><a href="sales-statement.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>Sales Statement</a></li>
</ul>
</li>

<li class=" nav-item"><a href="#"><i class="icon-percent"></i><span data-i18n="nav.dash.main" class="Commission">Commission</span></a>
<ul class="menu-content">
<li class="<?php if($left=='4'){?> active<?php }?>"><a href="commission-binary.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>Binary Bonus</a></li><li class="<?php if($left=='4'){?> active<?php }?>"><a href="commission-direct.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>Direct Bonus</a></li>



</ul>
</li>

<li class=" nav-item"><a href="#"><i class="icon-pin"></i><span data-i18n="nav.dash.main" class="E-Pin">E-Pin Generate</span></a>
<ul class="menu-content">
<li class="<?php if($left=='5'){?> active<?php }?>"><a href="epin.php?case=member" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>E-pin User</a></li>
<li class="<?php if($left=='5'){?> active<?php }?>"><a href="epin.php?case=admin" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>E-pin Admin</a></li>
<li class="<?php if($left=='5'){?> active<?php }?>"><a href="epin.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>View E-pin</a></li>

</ul>
</li>
<li class=" nav-item"><a href="#"><i class="icon-credit-card"></i><span data-i18n="nav.dash.main" class="Deposit">Deposit</span></a>
<ul class="menu-content">
<li class="<?php if($left=='6'){?> active<?php }?>"><a href="deposit.php?case=add" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>New Deposit</a></li>
<li class="<?php if($left=='6'){?> active<?php }?>"><a href="deposit.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>View Deposit</a></li>
</ul>
</li>

<li class=" nav-item"><a href="#"><i class="icon-dollar"></i><span data-i18n="nav.dash.main" class="Deduct">Deduct</span></a>
<ul class="menu-content">
<li class="<?php if($left=='10'){?> active<?php }?>"><a href="deduct.php?case=add" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>New Deduct</a></li>
<li class="<?php if($left=='10'){?> active<?php }?>"><a href="deduct.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>View Deduct</a></li>
</ul>
</li>

<li class=" nav-item"><a href="#"><i class="icon-dollar"></i><span data-i18n="nav.dash.main" class="Payment Request">Payment Request</span></a>
<ul class="menu-content">
<li class="<?php if($left=='12'){?> active<?php }?>"><a href="payment-request.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>View Statement</a></li>
</ul>
</li>

<li class=" nav-item"><a href="#"><i class="icon-money"></i><span data-i18n="nav.dash.main" class="Withdrawal">Withdrawal</span></a>
<ul class="menu-content">
<li class="<?php if($left=='7'){?> active<?php }?>"><a href="pending-withdrawal.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>Pending Withdrawal</a></li>
<li class="<?php if($left=='7'){?> active<?php }?>"><a href="approved-withdrawal.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>Approved Withdrawal</a></li>
<li class="<?php if($left=='7'){?> active<?php }?>"><a href="paid-withdrawal.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>Paid Withdrawal</a></li>
</ul>
</li>

<li class="nav-item"><a href="#"><i class="icon-group"></i><span data-i18n="nav.dash.main" class="Genealogy">Genealogy</span></a>
<ul class="menu-content">
<li class="<?php if($left=='8'){?> active<?php }?>"><a href="grid-view.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>Grid View</a></li>
<li class="<?php if($left=='8'){?> active<?php }?>"><a href="tree-view.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>Tree View</a></li>
</ul>
</li>




<li class=" nav-item"><a href="#"><i class="icon-megaphone"></i><span data-i18n="nav.dash.main" class="Announcement">Announcement</span></a>
<ul class="menu-content">
<li class="<?php if($left=='16'){?> active<?php }?>"><a href="announcement.php?case=add" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>New Message</a></li>
<li class="<?php if($left=='16'){?> active<?php }?>"><a href="announcement.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>View Message</a></li>
</ul>
</li>

<li class=" nav-item"><a href="#"><i class="icon-envelope"></i><span data-i18n="nav.dash.main" class="Others">Others</span></a>
<ul class="menu-content">
<li class="<?php if($left=='9'){?> active<?php }?>"><a href="contact.php?case=add" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>New Contact</a></li>
<li class="<?php if($left=='9'){?> active<?php }?>"><a href="contact.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>View Contact</a></li>
<li class="<?php if($left=='9'){?> active<?php }?>"><a href="feedback.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>View Feedback</a></li>
</ul>
</li>

<li class=" nav-item"><a href="#"><i class="icon-help"></i><span data-i18n="nav.dash.main" class="Support">Support</span></a>
<ul class="menu-content">
<li class="<?php if($left=='11'){?> active<?php }?>"><a href="support.php" data-i18n="nav.page_layouts.2_columns" class="menu-item"><i class="icon-arrow-right3"></i>View Support</a></li>
</ul>
</li>

<li class=" nav-item"><a href="logout.php" onclick="return confirm('Are you sure want to logout now?');"><i class="icon-power"></i><span data-i18n="nav.dash.main" class="menu-title">Logout</span></a></li>
</ul>
</div>
</div>