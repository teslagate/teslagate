<?php 
include('header.php'); 
$left=7;

$tds=getPaidTotalWithdrawal($conn,'tds');
$service=getPaidTotalWithdrawal($conn,'service');
$totalcharge=($tds=+$service);
?>
<style>
table,
thead,
tr,
tbody,
th,
td {
text-align: center;
}
</style>
<!-- main menu-->
<?php include('leftpanel.php'); ?>
<!-- / main menu-->
<div class="app-content content container-fluid">
<div class="content-wrapper" style="min-height:590px;">

<div class="content-body">
<div class="row">
<div class="col-xs-12">
<div class="card">
<div class="card-header">
<h4 class="card-title">Paid Withdrawal Statement</h4>
<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
<div class="heading-elements">
<ul class="list-inline mb-0">
<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
<li><a data-action="reload"><i class="icon-reload"></i></a></li>
<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
</ul>
</div>
</div>
<div class="card-body collapse in">

<div class="portlet box blue-hoki">
<div class="portlet-title">
<div class="caption">
<div>&nbsp;</div>

<table width="98%">
<tr><td>
<div align="left" style="margin-left:10px;"><a href="withdrawal-paid-csv-download.php"><input type="button" value="Excel Download" class="btn" style="background:#009900;color:#FFFFFF;" /></a></div>
</td>
<td>
<div align="right" style="padding:10px;">
<form name="form3" action="paid-withdrawal.php?act=search" method="post">
<input type="text" name="search" id="search" value="<?=$_REQUEST['search']?>" class="form-control border-primary" style="width:180px;" placeholder="User ID" />
</form>
</div>
</td>
</tr>
</table>
</div>
<div class="portlet-body" style="overflow:auto;">
<table width="80%" border="0" cellspacing="0" cellpadding="0" align="center">
<tr height="30" style="font-size:16px;color:#4378A3;">
<td width="23%" align="right" valign="middle"><strong style="font-size:14px;">Total Request Amount:</strong></td>
<td width="9%" align="left" valign="middle" style="font-size:14px;"><?=getPaidTotalWithdrawal($conn,'request')?></td>
<td width="24%" align="right" valign="middle"><strong style="font-size:14px;">Total Charge:</strong></td>
<td width="10%" align="left" valign="middle" style="font-size:14px;"><?=$totalcharge?><span></span></td>
<td width="22%" align="right" valign="middle"><strong style="font-size:14px;">Total Payout:</strong></td>
<td width="12%" align="left" valign="middle" style="font-size:14px;"><?=getPaidTotalWithdrawal($conn,'payout')?></td>
</tr>
</table>
<div>&nbsp;</div>
<div class="card-body" style="overflow:auto;background:#FFFFFF;">
 <table id="example1" class="table table-bordered table-striped">
<thead>
<tr><tr>
<td  align="center">Sl_No</td>
<td align="center">User_ID</td>
<td  align="center">Name</td>
<td  align="center">Request</td>

<td  align="center">Payout</td>
<td  align="center">USDT Wallet.</td>
<td  align="center">Status</td>
<td  align="center">Date</td>
</tr>
</thead>
<tbody>
<?php
$tname='or_withdrawal';
$lim=100;
$tpage='paid-withdrawal.php';
if($_REQUEST['act']=='search')
{
$where="WHERE `userid` LIKE '".trim(mysqli_real_escape_string($conn,$_POST['search']))."' AND `status`='C' AND `paid`='C' ORDER BY `id` DESC";
}else{
$where="WHERE `status`='C' AND `paid`='C' ORDER BY `id` DESC";
}
include('pagination.php');
$num=numrows($result);
$i=1;
if($num>0)
{
while($fetch=fetcharray($result))
{
?>
<div class="card-body" style="overflow:auto;background:#FFFFFF;">
 <table id="example1" class="table table-bordered table-striped">
<thead>
<tr height="30">
<td align="center" class="tborder" ><?=$i?></td>
<td align="center" class="tborder" ><?=$fetch['userid']?></td>
<td align="center" class="tborder" ><?=getMemberUserid($conn,$fetch['userid'],'name')?></td>
<td align="center" class="tborder" ><?=$fetch['request']?></td>

<td align="center" class="tborder" ><?=$fetch['payout']?></td>
<td align="center" class="tborder"><?=$fetch['usdtwallet']?></td>
<td align="center" class="tborder" ><?php if($fetch['status']=='C'){?><span style="color:#009900;">Approved</span><?php }?></td>
<td align="center" class="tborder" ><?=$fetch['date']?></td>
</tr>
<?php $i++;}}else{?>
<tr height="14"><td align="center" colspan="14" style="color:#FF0000;"><div class="norecord">No Record Found!</div></td></tr>
<?php }?>
</tbody>
</table>          

</div>
</div>
</div>
</div>

</div>
</div>
</div>
<div class="col-md-3">&nbsp;</div>
</div>
</div>
</div>
</div>
<!-- BEGIN VENDOR JS-->
<script src="app-assets/js/core/libraries/jquery.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/tether.min.js" type="text/javascript"></script>
<script src="app-assets/js/core/libraries/bootstrap.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/unison.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/blockUI.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/jquery.matchHeight-min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/screenfull.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/extensions/pace.min.js" type="text/javascript"></script>
<!-- BEGIN VENDOR JS-->
<script src="app-assets/js/core/app-menu.js" type="text/javascript"></script>
<script src="app-assets/js/core/app.js" type="text/javascript"></script>
<!-- END ROBUST JS-->
</body>
</html>