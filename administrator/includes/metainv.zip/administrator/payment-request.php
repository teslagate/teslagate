<?php include('header.php');
$left=12;
?>  
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- main menu-->
<?php include('leftpanel.php'); ?>

<?php  if($_REQUEST['case']==''){?>

<div class="app-content content container-fluid">
<div class="content-wrapper" style="min-height:590px;">

<div class="content-body">

<div class="row">
<div class="col-xs-12">
<div class="card">
<div class="card-header">
<h4 class="card-title">Payment Request</h4>
<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
<div class="heading-elements">
<ul class="list-inline mb-0">
<li><a data-action="collapse"><i class="icon-minus4"></i></a></li>
<li><a data-action="reload"><i class="icon-reload"></i></a></li>
<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
</ul>
</div>
</div>
<div class="card-body collapse in">
<div align="right" style="padding:5px;"><form name="frm1" method="post" action="payment-request.php?act=search"><input type="text" name="search" id="search" class="form-control input-line input-medium" value="<?=$_REQUEST['search']?>" required placeholder="User ID" style="width:150px;" />
</form></div>
<div class="card-body" style="overflow:auto;background:#FFFFFF;">
 <table id="example1" class="table table-bordered table-striped">
<thead>
<tr>
<td width="10%" align="center"><strong>Sl_No</strong></td>
<td width="10%" align="center"><strong>User_ID</strong></td>
<td width="10%" align="center"><strong>Name</strong></td>
<td width="15%" align="center"><strong>Transaction_ID</strong></td>
<td width="15%" align="center"><strong>Package</strong></td>

<td width="10%" align="center"><strong>Amount</strong></td>
<td width="15%" align="center"><strong>Slip</strong></td>
<td width="10%" align="center"><strong>Status</strong></td>
<td width="10%" align="center"><strong>Date</strong></td>
<td width="10%" align="center"><strong>Action</strong></td>
</tr>
</thead>
<tbody>
<?php
$tname='or_member_payment';
$lim=100;
$tpage='payment-request.php';

if($_REQUEST['act']=='search')
{
$where="WHERE `userid` LIKE '".trim(mysqli_real_escape_string($conn,$_POST['search']))."' ORDER BY `id` DESC";
}else{
$where="ORDER BY `id` DESC";
}
include('pagination.php');
$num=numrows($result);
$i=1;
if($num>0)
{
while($fetch=fetcharray($result))
{
?>  
<tr>
<td align="center" style="padding:5px;"><?=$i?></td>
<td align="center" style="padding:5px;"><?=$fetch['userid']?></a></td>
<td align="center" style="padding:5px;"><?=getMemberUserid($conn,$fetch['userid'],'name')?></td>
<td align="center" style="padding:5px;"><?=$fetch['tranid']?></a></td>
<td align="center" style="padding:5px;"> <?= getSettingsJoining($conn,$fetch['packid'],'pack_name')?> </a></td>
<td align="center" style="padding:5px;"><?=$fetch['amount']?></td>
<td align="center" style="padding:5px;"><a href="file-download-payment.php?f=<?=$fetch['slip']?>" style="cursor:pointer;"><img src="images/download.gif" height="40"></a></td>

<td align="center" style="padding:5px;"><?php if($fetch['status']=='P'){?><a href="payment-request-process.php?case=status&id=<?=$fetch['id']?>&st=<?=$fetch['status']?>&page=<?=$_REQUEST['page']?>" style="text-decoration:none;"><span style="color:#FFFFFF;background:#FF0000;padding:2px 10px;border-radius:5px;" onClick="return confirm('Are you sure want to change status ?');">Pending</span></a><?php }else{?><span style="color:#FFFFFF;background:#009900;padding:2px 10px;border-radius:5px;">Approved</span><?php }?></td>

<td align="center" style="padding:5px;"><?=$fetch['date']?></td>

<td align="center" style="padding:5px;"><?php if($fetch['status']=='P'){?><a href="payment-request-process.php?case=delete&id=<?=$fetch['id']?>&page=<?=$_REQUEST['page']?>" class="btn btn-danger" onClick="return confirm('Are you sure want to delete this record?');"><i class="fa fa-times icon-only"></i></a><?php }else{?>---<?php }?></td>
</tr>
<?php $i++;}}else{?>
<tr><td colspan="9" align="center" style="color:#FF0000;">No Record Found!</td></tr>
<?php }?>
</tbody>
</table>
<div align="center"><?=$pagination?></div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php }?>

<!-- BEGIN VENDOR JS-->
<script src="app-assets/js/core/libraries/jquery.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/tether.min.js" type="text/javascript"></script>
<script src="app-assets/js/core/libraries/bootstrap.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/unison.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/blockUI.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/jquery.matchHeight-min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/ui/screenfull.min.js" type="text/javascript"></script>
<script src="app-assets/vendors/js/extensions/pace.min.js" type="text/javascript"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN ROBUST JS-->
<script src="app-assets/js/core/app-menu.js" type="text/javascript"></script>
<script src="app-assets/js/core/app.js" type="text/javascript"></script>
<!-- END ROBUST JS-->
</body>
</html>