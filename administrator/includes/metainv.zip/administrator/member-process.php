<?php
session_start();
include('includes/function.php');
if(!isset($_SESSION['sid']))
{
redirect('index.php');
}

if($_SESSION['sid'])
{
if($_SERVER['REQUEST_METHOD']=='POST')
{
if($_REQUEST['case']=='add')
{ 
$userid=$usercode.rand(1111111,9999999);

$sql="INSERT INTO `or_member` (`userid`,`name`,`email`,`phone`,`password`,`address`,`date`,`bname`,`branch`,`accname`,`accno`,`ifscode`,`pancard`,`aadhar`,`status`,`paystatus`,`approved`) VALUES('".$userid."','".mysqli_real_escape_string($conn,$_POST['name'])."','".mysqli_real_escape_string($conn,$_POST['email'])."','".trim(mysqli_real_escape_string($conn,$_POST['phone']))."','".base64_encode($_POST['password'])."','".mysqli_real_escape_string($conn,$_POST['address'])."','".date('Y-m-d')."','".mysqli_real_escape_string($conn,$_POST['bname'])."','".mysqli_real_escape_string($conn,$_POST['branch'])."','".mysqli_real_escape_string($conn,$_POST['accname'])."','".mysqli_real_escape_string($conn,$_POST['accno'])."','".mysqli_real_escape_string($conn,$_POST['ifscode'])."','".mysqli_real_escape_string($conn,$_POST['pancard'])."','".mysqli_real_escape_string($conn,$_POST['aadhar'])."','A','A','".date('Y-m-d')."')";
$res=query($conn,$sql);

$sql1="INSERT INTO `or_genealogy`(`userid`,`placement`,`position`,`date`) VALUES('".$userid."','','','".date('Y-m-d')."')";
$res1=query($conn,$sql1);

$sql2="INSERT INTO `or_member_count`(`userid`,`left`,`right`) VALUES('".$userid."','0','0')";
$res2=query($conn,$sql2);

$sql3="INSERT INTO `or_member_count_pair`(`userid`,`left`,`right`) VALUES('".$userid."','0','0')";
$res3=query($conn,$sql3);

$sql4="INSERT INTO `or_member_sales`(`userid`,`left`,`right`) VALUES('".$userid."','0','0')";
$res4=query($conn,$sql4);

$recharge=getSettingsJoining($conn,'recharge');
if($recharge>0)
{
$nomonth=getSettingsJoining($conn,'nomonth');
if($nomonth>0)
{
for($i=0;$i<$nomonth;$i++)
{
$nom=(30*$i);
$stdate1=date('Y-m-d',strtotime('+'.$nom.' days',strtotime(date("Y-m-d"))));

$sql7="INSERT INTO `or_commission_recharge` (`userid`,`bonus`,`status`,`date`) VALUES('".$userid."','".$recharge."','H','".$stdate1."')";
$res7=query($conn,$sql7);
}

}
}

redirect('member.php');
}

if($_REQUEST['case']=='edit')
{
$sql3="UPDATE `or_member` SET `name`='".mysqli_escape_string($conn,$_POST['name'])."',`email`='".mysqli_escape_string($conn,$_POST['email'])."',`phone`='".mysqli_escape_string($conn,$_POST['phone'])."',`password`='".base64_encode(mysqli_escape_string($conn,$_POST['password']))."',`address`='".mysqli_escape_string($conn,$_POST['address'])."',`bname`='".mysqli_escape_string($conn,$_POST['bname'])."',`branch`='".mysqli_escape_string($conn,$_POST['branch'])."',`accname`='".mysqli_escape_string($conn,$_POST['accname'])."',`accno`='".mysqli_escape_string($conn,$_POST['accno'])."',`ifscode`='".mysqli_escape_string($conn,$_POST['ifscode'])."',`pancard`='".mysqli_escape_string($conn,$_POST['pancard'])."',`minerincome`='".trim(mysqli_real_escape_string($conn,$_POST['minerincome']))."',`carrerplan`='".trim(mysqli_real_escape_string($conn,$_POST['carrerplan']))."',`aadhar`='".mysqli_escape_string($conn,$_POST['aadhar'])."' WHERE `id`='".mysqli_escape_string($conn,$_REQUEST['id'])."'";
$res3=query($conn,$sql3);

redirect('member.php');
}
}

if($_REQUEST['case']=='delete')
{
$sql="DELETE FROM `or_member` WHERE `id`='".trim(mysqli_real_escape_string($conn,$_REQUEST['id']))."'";
$res=query($conn,$sql);

redirect('member.php');
}
}
?>