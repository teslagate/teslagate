<?php
session_start();
include('includes/function.php');

if($_SESSION['sid'])
{
if($_REQUEST['case']=='feedback')
{
$sql="DELETE FROM `or_feedback` WHERE `id`='".$_REQUEST['id']."'";
$res=query($conn,$sql);

redirect('feedback.php?page='.$_REQUEST['page']);
}
}
?> 