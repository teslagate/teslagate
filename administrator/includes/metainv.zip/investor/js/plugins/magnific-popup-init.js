$(document).ready(function () {
    $('.popup-youtube').magnificPopup({
        type: 'iframe'
    });
});